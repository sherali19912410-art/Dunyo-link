const {
  initializeTestEnvironment,
  assertFails,
  assertSucceeds,
} = require("@firebase/rules-unit-testing");
const { test, before, after, beforeEach } = require("node:test");
const fs = require("node:fs");
const nowTs = () => new Date(Date.now() - 1000);

let testEnv;
const PROJECT_ID = process.env.GCP_PROJECT || "demo-no-project";
const ALICE_UID = "alice_uid_123";
const BOB_UID = "bob_uid_456";
const CHARLIE_UID = "charlie_uid_789";

const [emulatorHost, emulatorPortStr] = (process.env.FIRESTORE_EMULATOR_HOST || "127.0.0.1:8085").split(":");
const emulatorPort = parseInt(emulatorPortStr, 10);

before(async () => {
  const rules = fs.readFileSync("./firestore.rules", "utf8");
  testEnv = await initializeTestEnvironment({
    projectId: PROJECT_ID,
    firestore: {
      rules,
      host: emulatorHost,
      port: emulatorPort,
    },
  });
});

after(async () => {
  if (testEnv) {
    await testEnv.cleanup();
  }
});

beforeEach(async () => {
  if (testEnv) {
    await testEnv.clearFirestore();
  }
});

test("Unauthenticated user: cannot read or write directory, chats, or messages", async () => {
  const unauthDb = testEnv.unauthenticatedContext().firestore();
  await assertFails(unauthDb.collection("directory").doc("DL1001").get());
  await assertFails(unauthDb.collection("chats").get());
  await assertFails(unauthDb.collection("chats").doc("c1").collection("messages").get());
});

test("Directory: owner can create and update displayName, non-owner cannot update or list all", async () => {
  const aliceDb = testEnv.authenticatedContext(ALICE_UID).firestore();
  const bobDb = testEnv.authenticatedContext(BOB_UID).firestore();

  await assertSucceeds(
    aliceDb.collection("directory").doc("DLALICE1").set({
      userId: ALICE_UID,
      displayName: "Ali",
      code: "DLALICE1",
      createdAt: nowTs(),
      updatedAt: nowTs(),
    })
  );

  // Bob can look up Alice by exact short code
  await assertSucceeds(bobDb.collection("directory").doc("DLALICE1").get());

  // Bob cannot list Alice's directory entry or list all entries without userId == BOB_UID
  await assertFails(bobDb.collection("directory").get());
  await assertFails(bobDb.collection("directory").where("userId", "==", ALICE_UID).get());

  // Bob can list only his own directory entry
  await assertSucceeds(bobDb.collection("directory").where("userId", "==", BOB_UID).get());

  // Bob cannot overwrite Alice's directory entry
  await assertFails(
    bobDb.collection("directory").doc("DLALICE1").update({
      displayName: "Hacked",
      updatedAt: nowTs(),
    })
  );

  // Shadow update with ghost field must fail
  await assertFails(
    aliceDb.collection("directory").doc("DLALICE1").set({
      userId: ALICE_UID,
      displayName: "Ali",
      code: "DLALICE1",
      isAdmin: true,
      createdAt: nowTs(),
      updatedAt: nowTs(),
    })
  );
});

test("Chats & Messages: members can create chat, send messages, and non-members are denied", async () => {
  const aliceDb = testEnv.authenticatedContext(ALICE_UID).firestore();
  const bobDb = testEnv.authenticatedContext(BOB_UID).firestore();
  const charlieDb = testEnv.authenticatedContext(CHARLIE_UID).firestore();
  const chatId = `${ALICE_UID}_${BOB_UID}`;

  // Alice creates a chat with Bob
  await assertSucceeds(
    aliceDb.collection("chats").doc(chatId).set({
      memberUids: [ALICE_UID, BOB_UID],
      memberNames: {
        [ALICE_UID]: "Ali",
        [BOB_UID]: "Vali",
      },
      lastMessageText: "",
      lastMessageSenderId: "",
      createdAt: nowTs(),
      updatedAt: nowTs(),
    })
  );

  // Alice sends a message
  await assertSucceeds(
    aliceDb.collection("chats").doc(chatId).collection("messages").doc("msg1").set({
      chatId,
      senderId: ALICE_UID,
      senderName: "Ali",
      text: "Salom Vali!",
      memberUids: [ALICE_UID, BOB_UID],
      createdAt: nowTs(),
    })
  );

  // Bob can list his chats and messages in the chat
  await assertSucceeds(bobDb.collection("chats").where("memberUids", "array-contains", BOB_UID).get());
  await assertSucceeds(
    bobDb.collection("chats").doc(chatId).collection("messages").where("memberUids", "array-contains", BOB_UID).get()
  );

  // Bob replies
  await assertSucceeds(
    bobDb.collection("chats").doc(chatId).collection("messages").doc("msg2").set({
      chatId,
      senderId: BOB_UID,
      senderName: "Vali",
      text: "Vaalaykum salom!",
      memberUids: [ALICE_UID, BOB_UID],
      createdAt: nowTs(),
    })
  );

  // Charlie cannot read, list, or write to Alice & Bob's chat or messages
  await assertFails(charlieDb.collection("chats").doc(chatId).get());
  await assertFails(charlieDb.collection("chats").get());
  await assertFails(
    charlieDb.collection("chats").doc(chatId).collection("messages").get()
  );
  await assertFails(
    charlieDb.collection("chats").doc(chatId).collection("messages").doc("msg1").get()
  );
  await assertFails(
    charlieDb.collection("chats").doc(chatId).collection("messages").doc("msg3").set({
      chatId,
      senderId: CHARLIE_UID,
      senderName: "Charlie",
      text: "Intruder",
      memberUids: [ALICE_UID, BOB_UID, CHARLIE_UID],
      createdAt: nowTs(),
    })
  );

  // Identity spoofing: Bob cannot send a message pretending to be Alice
  await assertFails(
    bobDb.collection("chats").doc(chatId).collection("messages").doc("msg_spoof").set({
      chatId,
      senderId: ALICE_UID,
      senderName: "Ali",
      text: "Spoofed!",
      memberUids: [ALICE_UID, BOB_UID],
      createdAt: nowTs(),
    })
  );

  // Messages are immutable (cannot update or delete)
  await assertFails(
    aliceDb.collection("chats").doc(chatId).collection("messages").doc("msg1").update({
      text: "Edited",
    })
  );
  await assertFails(
    aliceDb.collection("chats").doc(chatId).collection("messages").doc("msg1").delete()
  );
});
