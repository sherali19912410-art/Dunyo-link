package com.example.data.repository

import com.example.base.FirestoreEmulatorTestBase
import com.google.firebase.firestore.FirebaseFirestoreException
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.runBlocking
import kotlinx.coroutines.withTimeout
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Assert.fail
import org.junit.Test

class ChatRepositoryRuleTest : FirestoreEmulatorTestBase() {

  @Test
  fun twoUsers_connectByCode_sendAndObserveMessages() = runBlocking {
    val aliceUid = signInTestUser(ALICE_EMAIL)
    val aliceRepo = ChatRepository(firestore, auth)
    val aliceEntry =
      withTimeout(DEFAULT_TIMEOUT_MS) { aliceRepo.ensureDirectoryEntry("Ali").getOrThrow() }
    assertTrue(aliceEntry.code.startsWith("DL"))

    val bobUid = signInTestUser(BOB_EMAIL)
    val bobRepo = ChatRepository(firestore, auth)
    withTimeout(DEFAULT_TIMEOUT_MS) { bobRepo.ensureDirectoryEntry("Vali").getOrThrow() }

    val lookedUpAlice =
      withTimeout(DEFAULT_TIMEOUT_MS) { bobRepo.findUserByCode(aliceEntry.code).getOrThrow() }
    assertNotNull(lookedUpAlice)
    assertEquals(aliceUid, lookedUpAlice?.userId)

    val chatId =
      withTimeout(DEFAULT_TIMEOUT_MS) {
        bobRepo.startOrOpenChat(aliceUid, "Ali", "Vali").getOrThrow()
      }

    val uniqueTag = java.util.UUID.randomUUID().toString().take(8)
    val msg1Text = "Salom Ali! $uniqueTag"
    val msg2Text = "Vaalaykum salom Vali! $uniqueTag"

    val members = listOf(aliceUid, bobUid).sorted()
    val msg1Id =
      withTimeout(DEFAULT_TIMEOUT_MS) {
        bobRepo.sendMessage(chatId, members, "Vali", msg1Text).getOrThrow()
      }

    // Switch to Alice and verify she observes both the chat and the message in real time
    signInTestUser(ALICE_EMAIL)
    val aliceChats =
      withTimeout(FLOW_TIMEOUT_MS) {
        aliceRepo.observeChats(aliceUid).first { list ->
          list.any { it.id == chatId && it.lastMessageText == msg1Text }
        }
      }
    assertEquals(msg1Text, aliceChats.first { it.id == chatId }.lastMessageText)

    val messagesForAlice =
      withTimeout(FLOW_TIMEOUT_MS) {
        aliceRepo.observeMessages(chatId, aliceUid).first { list -> list.any { it.id == msg1Id } }
      }
    assertTrue(messagesForAlice.any { it.id == msg1Id && it.text == msg1Text })

    // Alice replies
    val msg2Id =
      withTimeout(DEFAULT_TIMEOUT_MS) {
        aliceRepo.sendMessage(chatId, members, "Ali", msg2Text).getOrThrow()
      }

    val updatedMessages =
      withTimeout(FLOW_TIMEOUT_MS) {
        aliceRepo.observeMessages(chatId, aliceUid).first { list -> list.any { it.id == msg2Id } }
      }
    assertTrue(updatedMessages.any { it.id == msg1Id })
    assertTrue(updatedMessages.any { it.id == msg2Id && it.text == msg2Text })
  }

  @Test
  fun observeMessages_crossUserUnauthorized_failsWithPermissionDenied() = runBlocking {
    val aliceUid = signInTestUser(ALICE_EMAIL)
    val aliceRepo = ChatRepository(firestore, auth)
    val bobUid = signInTestUser(BOB_EMAIL)
    val bobRepo = ChatRepository(firestore, auth)

    val chatId =
      withTimeout(DEFAULT_TIMEOUT_MS) {
        bobRepo.startOrOpenChat(aliceUid, "Ali", "Vali").getOrThrow()
      }
    val members = listOf(aliceUid, bobUid).sorted()
    withTimeout(DEFAULT_TIMEOUT_MS) {
      bobRepo.sendMessage(chatId, members, "Vali", "Maxfiy xabar").getOrThrow()
    }

    val charlieUid = signInTestUser(CHARLIE_EMAIL)
    val charlieRepo = ChatRepository(firestore, auth)

    // Filtered query returns 0 messages (never leaks Bob/Alice's messages)
    val charlieFiltered =
      withTimeout(FLOW_TIMEOUT_MS) {
        charlieRepo.observeMessages(chatId, charlieUid).first()
      }
    assertTrue(charlieFiltered.isEmpty())

    // Direct read of the chat room by Charlie must fail with PERMISSION_DENIED
    try {
      withTimeout(FLOW_TIMEOUT_MS) {
        charlieRepo.observeChatRoom(chatId, charlieUid).first()
      }
      fail("Expected PERMISSION_DENIED when Charlie observes Alice & Bob's chat room")
    } catch (e: Exception) {
      val firestoreException = checkNotNull(e.unwrapFirestoreException()) {
        "Expected nested FirebaseFirestoreException, got $e"
      }
      assertEquals(FirebaseFirestoreException.Code.PERMISSION_DENIED, firestoreException.code)
    }

    // Attempting to send a message as Charlie into Alice & Bob's chat must fail with PERMISSION_DENIED
    val sendAttempt =
      withTimeout(DEFAULT_TIMEOUT_MS) {
        charlieRepo.sendMessage(chatId, listOf(aliceUid, bobUid, charlieUid), "Charlie", "Intruder")
      }
    assertTrue(sendAttempt.isFailure)
    val sendFirestoreEx = checkNotNull(sendAttempt.exceptionOrNull()?.unwrapFirestoreException()) {
      "Expected nested FirebaseFirestoreException, got ${sendAttempt.exceptionOrNull()}"
    }
    assertEquals(FirebaseFirestoreException.Code.PERMISSION_DENIED, sendFirestoreEx.code)
  }

  @Test
  fun observeChats_unauthenticatedUser_failsWithPermissionDenied() = runBlocking {
    auth.signOut()
    val repo = ChatRepository(firestore, auth)

    try {
      withTimeout(FLOW_TIMEOUT_MS) {
        repo.observeChats("some_uid").first()
      }
      fail("Expected PERMISSION_DENIED when unauthenticated")
    } catch (e: Exception) {
      val firestoreException = checkNotNull(e.unwrapFirestoreException()) {
        "Expected nested FirebaseFirestoreException, got $e"
      }
      assertEquals(FirebaseFirestoreException.Code.PERMISSION_DENIED, firestoreException.code)
    }
  }

  private companion object {
    const val ALICE_EMAIL = "alice_dunyo@test.com"
    const val BOB_EMAIL = "bob_dunyo@test.com"
    const val CHARLIE_EMAIL = "charlie_dunyo@test.com"
    const val DEFAULT_TIMEOUT_MS = 5000L
    const val FLOW_TIMEOUT_MS = 3000L
  }
}
