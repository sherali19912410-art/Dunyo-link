package com.example.data.repository

import android.content.Context
import com.example.R
import com.example.data.model.ChatMessage
import com.example.data.model.ChatRoom
import com.example.data.model.DirectoryEntry
import com.example.data.remote.OperationType
import com.example.data.remote.handleFirestoreError
import com.google.firebase.Firebase
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.auth
import com.google.firebase.firestore.DocumentSnapshot.ServerTimestampBehavior
import com.google.firebase.firestore.FieldValue
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.FirebaseFirestoreException
import com.google.firebase.firestore.snapshots
import java.security.MessageDigest
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.emitAll
import kotlinx.coroutines.flow.flow
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.tasks.await

class ChatRepository(
  private val db: FirebaseFirestore,
  private val auth: FirebaseAuth = Firebase.auth,
) {
  constructor(context: Context) : this(
    FirebaseFirestore.getInstance(
      context.applicationContext.getString(R.string.firestore_database_id)
    ),
    Firebase.auth,
  )

  private fun requireUserId(): String {
    return auth.currentUser?.uid
      ?: throw IllegalStateException("Foydalanuvchi tizimga kirmagan.")
  }

  fun computeUserCode(uid: String): String {
    val digest = MessageDigest.getInstance("SHA-256").digest(uid.toByteArray())
    val alphabet = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789"
    val chars = CharArray(6) { idx ->
      val unsigned = digest[idx].toInt() and 0xFF
      alphabet[unsigned % alphabet.length]
    }
    return "DL${String(chars)}"
  }

  suspend fun ensureDirectoryEntry(rawDisplayName: String): Result<DirectoryEntry> {
    val uid = requireUserId()
    val code = computeUserCode(uid)
    val cleanName = rawDisplayName.trim().ifBlank { "Foydalanuvchi" }.take(80)
    val docRef = db.collection("directory").document(code)

    return try {
      val existing = docRef.get().await()
      if (!existing.exists()) {
        val payload =
          mapOf(
            "userId" to uid,
            "displayName" to cleanName,
            "code" to code,
            "createdAt" to FieldValue.serverTimestamp(),
            "updatedAt" to FieldValue.serverTimestamp(),
          )
        docRef.set(payload).await()
      } else if (existing.getString("displayName") != cleanName) {
        docRef
          .update(
            mapOf(
              "displayName" to cleanName,
              "updatedAt" to FieldValue.serverTimestamp(),
            )
          )
          .await()
      }
      val saved = docRef.get().await().toObject(DirectoryEntry::class.java, ServerTimestampBehavior.ESTIMATE)
        ?: DirectoryEntry(id = code, userId = uid, displayName = cleanName, code = code)
      Result.success(saved)
    } catch (e: CancellationException) {
      throw e
    } catch (e: Exception) {
      handleFirestoreError(e, OperationType.WRITE, docRef.path, auth)
      Result.failure(e)
    }
  }

  suspend fun findUserByCode(rawCode: String): Result<DirectoryEntry?> {
    requireUserId()
    val normalized = rawCode.trim().uppercase().replace(" ", "")
    if (normalized.length < 4 || !normalized.matches(Regex("^[A-Z0-9_\\-]+$"))) {
      return Result.success(null)
    }
    val docRef = db.collection("directory").document(normalized)
    return try {
      val snapshot = docRef.get().await()
      if (!snapshot.exists()) {
        Result.success(null)
      } else {
        Result.success(
          snapshot.toObject(DirectoryEntry::class.java, ServerTimestampBehavior.ESTIMATE)
        )
      }
    } catch (e: CancellationException) {
      throw e
    } catch (e: Exception) {
      handleFirestoreError(e, OperationType.GET, docRef.path, auth)
      Result.failure(e)
    }
  }

  fun observeChats(currentUserId: String): Flow<List<ChatRoom>> = flow {
    val path = "chats"
    emitAll(
      db.collection(path)
        .whereArrayContains("memberUids", currentUserId)
        .snapshots()
        .map { snapshot ->
          snapshot
            .toObjects(ChatRoom::class.java, ServerTimestampBehavior.ESTIMATE)
            .sortedByDescending { it.updatedAt?.toDate()?.time ?: it.createdAt?.toDate()?.time ?: 0L }
        }
        .catch { error ->
          val firestoreError =
            generateSequence(error) { it.cause }
              .filterIsInstance<FirebaseFirestoreException>()
              .firstOrNull()
          if (firestoreError == null && error is CancellationException) throw error
          val exceptionToLog = firestoreError ?: (error as? Exception)
          if (exceptionToLog != null && auth.currentUser?.uid == currentUserId) {
            handleFirestoreError(exceptionToLog, OperationType.LIST, path, auth)
          }
          throw error
        }
    )
  }

  suspend fun startOrOpenChat(
    peerUserId: String,
    peerDisplayName: String,
    myDisplayName: String,
  ): Result<String> {
    val myUid = requireUserId()
    val myCleanName = myDisplayName.trim().ifBlank { "Men" }.take(80)
    val peerCleanName = peerDisplayName.trim().ifBlank { "Suhbatdosh" }.take(80)

    val isSelf = peerUserId == myUid
    val memberUids = if (isSelf) listOf(myUid) else listOf(myUid, peerUserId).sorted()
    val chatId = if (isSelf) "self_$myUid" else "${memberUids[0]}_${memberUids[1]}"
    val memberNames =
      if (isSelf) {
        mapOf(myUid to myCleanName)
      } else {
        mapOf(myUid to myCleanName, peerUserId to peerCleanName)
      }

    val docRef = db.collection("chats").document(chatId)
    return try {
      val existing = docRef.get().await()
      if (!existing.exists()) {
        val payload =
          mapOf(
            "memberUids" to memberUids,
            "memberNames" to memberNames,
            "lastMessageText" to "",
            "lastMessageSenderId" to "",
            "createdAt" to FieldValue.serverTimestamp(),
            "updatedAt" to FieldValue.serverTimestamp(),
          )
        docRef.set(payload).await()
      }
      Result.success(chatId)
    } catch (e: CancellationException) {
      throw e
    } catch (e: Exception) {
      handleFirestoreError(e, OperationType.WRITE, docRef.path, auth)
      Result.failure(e)
    }
  }

  fun observeChatRoom(chatId: String, currentUserId: String): Flow<ChatRoom?> = flow {
    val docRef = db.collection("chats").document(chatId)
    emitAll(
      docRef
        .snapshots()
        .map { snapshot ->
          if (snapshot.exists()) {
            snapshot.toObject(ChatRoom::class.java, ServerTimestampBehavior.ESTIMATE)
          } else {
            null
          }
        }
        .catch { error ->
          val firestoreError =
            generateSequence(error) { it.cause }
              .filterIsInstance<FirebaseFirestoreException>()
              .firstOrNull()
          if (firestoreError == null && error is CancellationException) throw error
          val exceptionToLog = firestoreError ?: (error as? Exception)
          if (exceptionToLog != null && auth.currentUser?.uid == currentUserId) {
            handleFirestoreError(exceptionToLog, OperationType.GET, docRef.path, auth)
          }
          throw error
        }
    )
  }

  fun observeMessages(chatId: String, currentUserId: String): Flow<List<ChatMessage>> = flow {
    val path = "chats/$chatId/messages"
    emitAll(
      db.collection("chats")
        .document(chatId)
        .collection("messages")
        .whereArrayContains("memberUids", currentUserId)
        .snapshots()
        .map { snapshot ->
          snapshot
            .toObjects(ChatMessage::class.java, ServerTimestampBehavior.ESTIMATE)
            .sortedBy { it.createdAt?.toDate()?.time ?: Long.MAX_VALUE }
        }
        .catch { error ->
          val firestoreError =
            generateSequence(error) { it.cause }
              .filterIsInstance<FirebaseFirestoreException>()
              .firstOrNull()
          if (firestoreError == null && error is CancellationException) throw error
          val exceptionToLog = firestoreError ?: (error as? Exception)
          if (exceptionToLog != null && auth.currentUser?.uid == currentUserId) {
            handleFirestoreError(exceptionToLog, OperationType.LIST, path, auth)
          }
          throw error
        }
    )
  }

  suspend fun sendMessage(
    chatId: String,
    memberUids: List<String>,
    senderName: String,
    text: String,
  ): Result<String> {
    val uid = requireUserId()
    val cleanText = text.trim()
    if (cleanText.isEmpty()) {
      return Result.failure(IllegalArgumentException("Xabar bo‘sh bo‘lmasligi kerak."))
    }
    val cleanSenderName = senderName.trim().ifBlank { "Foydalanuvchi" }.take(80)
    val chatRef = db.collection("chats").document(chatId)
    val msgRef = chatRef.collection("messages").document()

    val messagePayload =
      mapOf(
        "chatId" to chatId,
        "senderId" to uid,
        "senderName" to cleanSenderName,
        "text" to cleanText.take(2000),
        "memberUids" to memberUids,
        "createdAt" to FieldValue.serverTimestamp(),
      )

    val chatUpdatePayload =
      mapOf(
        "lastMessageText" to cleanText.take(2000),
        "lastMessageSenderId" to uid,
        "updatedAt" to FieldValue.serverTimestamp(),
      )

    return try {
      val batch = db.batch()
      batch.set(msgRef, messagePayload)
      batch.update(chatRef, chatUpdatePayload)
      batch.commit().await()
      Result.success(msgRef.id)
    } catch (e: CancellationException) {
      throw e
    } catch (e: Exception) {
      handleFirestoreError(e, OperationType.WRITE, msgRef.path, auth)
      Result.failure(e)
    }
  }
}
