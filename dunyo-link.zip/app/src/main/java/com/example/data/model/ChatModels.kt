package com.example.data.model

import com.google.firebase.Timestamp
import com.google.firebase.firestore.DocumentId
import com.google.firebase.firestore.IgnoreExtraProperties
import com.google.firebase.firestore.ServerTimestamp

@IgnoreExtraProperties
data class DirectoryEntry(
  @DocumentId val id: String = "",
  val userId: String = "",
  val displayName: String = "",
  val code: String = "",
  @ServerTimestamp val createdAt: Timestamp? = null,
  @ServerTimestamp val updatedAt: Timestamp? = null,
)

@IgnoreExtraProperties
data class ChatRoom(
  @DocumentId val id: String = "",
  val memberUids: List<String> = emptyList(),
  val memberNames: Map<String, String> = emptyMap(),
  val lastMessageText: String = "",
  val lastMessageSenderId: String = "",
  @ServerTimestamp val createdAt: Timestamp? = null,
  @ServerTimestamp val updatedAt: Timestamp? = null,
) {
  fun peerName(currentUserId: String): String {
    val peerEntry = memberNames.entries.firstOrNull { it.key != currentUserId }
    if (peerEntry != null && peerEntry.value.isNotBlank()) {
      return peerEntry.value
    }
    return memberNames[currentUserId]?.takeIf { it.isNotBlank() }?.let { "$it (O‘zim)" }
      ?: "Suhbat"
  }

  fun isSelfChat(currentUserId: String): Boolean =
    memberUids.size == 1 && memberUids.firstOrNull() == currentUserId
}

@IgnoreExtraProperties
data class ChatMessage(
  @DocumentId val id: String = "",
  val chatId: String = "",
  val senderId: String = "",
  val senderName: String = "",
  val text: String = "",
  val memberUids: List<String> = emptyList(),
  @ServerTimestamp val createdAt: Timestamp? = null,
)
