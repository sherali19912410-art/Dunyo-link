package com.example.ui.theme

import androidx.compose.ui.graphics.Color

val CobaltPrimary = Color(0xFF0F4C81)
val CobaltOnPrimary = Color(0xFFFFFFFF)
val CobaltPrimaryContainer = Color(0xFFD6E7FF)
val CobaltOnPrimaryContainer = Color(0xFF001C3A)

val AquaSecondary = Color(0xFF007A78)
val AquaOnSecondary = Color(0xFFFFFFFF)
val AquaSecondaryContainer = Color(0xFFBCECE9)
val AquaOnSecondaryContainer = Color(0xFF00201F)

val SkyTertiary = Color(0xFF3E6373)
val LightBackground = Color(0xFFF6F9FC)
val LightSurface = Color(0xFFFFFFFF)
val LightSurfaceVariant = Color(0xFFE6EDF5)
val LightOutline = Color(0xFFC2CDD9)

val DarkPrimary = Color(0xFF8CC5FF)
val DarkOnPrimary = Color(0xFF002F5C)
val DarkPrimaryContainer = Color(0xFF0F4C81)
val DarkOnPrimaryContainer = Color(0xFFD6E7FF)

val DarkSecondary = Color(0xFF5AD7D4)
val DarkOnSecondary = Color(0xFF003736)
val DarkSecondaryContainer = Color(0xFF00504E)
val DarkOnSecondaryContainer = Color(0xFFBCECE9)

val DarkBackground = Color(0xFF0C131F)
val DarkSurface = Color(0xFF131C2B)
val DarkSurfaceVariant = Color(0xFF1F2B3E)
val DarkOutline = Color(0xFF3B4A62)

val OnlineGreen = Color(0xFF1DB954)
