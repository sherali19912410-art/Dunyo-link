package com.example.ui.chat

import android.util.Log
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.model.ChatMessage
import com.example.data.model.ChatRoom
import com.example.data.repository.ChatRepository
import com.google.firebase.firestore.FirebaseFirestoreException
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.flatMapLatest
import kotlinx.coroutines.flow.flowOf
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

sealed interface UiState<out T> {
  data object Loading : UiState<Nothing>
  data class Success<T>(val data: T) : UiState<T>
  data class Error(val message: String) : UiState<Nothing>
}

@OptIn(ExperimentalCoroutinesApi::class)
class ChatViewModel(
  private val repository: ChatRepository,
  val currentUserId: String,
  val currentUserDisplayName: String,
) : ViewModel() {

  val myCode: String = repository.computeUserCode(currentUserId)

  private val _activeChatId = MutableStateFlow<String?>(null)
  val activeChatId: StateFlow<String?> = _activeChatId.asStateFlow()

  private val _connectInProgress = MutableStateFlow(false)
  val connectInProgress: StateFlow<Boolean> = _connectInProgress.asStateFlow()

  private val _connectError = MutableStateFlow<String?>(null)
  val connectError: StateFlow<String?> = _connectError.asStateFlow()

  private val _isSending = MutableStateFlow(false)
  val isSending: StateFlow<Boolean> = _isSending.asStateFlow()

  private val _sendError = MutableStateFlow<String?>(null)
  val sendError: StateFlow<String?> = _sendError.asStateFlow()

  val chatsState: StateFlow<UiState<List<ChatRoom>>> =
    repository
      .observeChats(currentUserId)
      .map<List<ChatRoom>, UiState<List<ChatRoom>>> { UiState.Success(it) }
      .catch { error ->
        val firestoreError =
          generateSequence(error) { it.cause }
            .filterIsInstance<FirebaseFirestoreException>()
            .firstOrNull()
        if (firestoreError == null && error is CancellationException) throw error
        val rootError = firestoreError ?: error
        Log.w(TAG, "Error observing chats", rootError)
        emit(UiState.Error(rootError.message ?: "Suhbatlarni yuklashda xatolik"))
      }
      .stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(STOP_TIMEOUT_MILLIS),
        initialValue = UiState.Loading,
      )

  val activeChatRoom: StateFlow<ChatRoom?> =
    _activeChatId
      .flatMapLatest { chatId ->
        if (chatId == null) {
          flowOf(null)
        } else {
          repository.observeChatRoom(chatId, currentUserId).catch { error ->
            val firestoreError =
              generateSequence(error) { it.cause }
                .filterIsInstance<FirebaseFirestoreException>()
                .firstOrNull()
            if (firestoreError == null && error is CancellationException) throw error
            Log.w(TAG, "Error observing chat room", firestoreError ?: error)
            emit(null)
          }
        }
      }
      .stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(STOP_TIMEOUT_MILLIS),
        initialValue = null,
      )

  val messagesState: StateFlow<UiState<List<ChatMessage>>> =
    _activeChatId
      .flatMapLatest { chatId ->
        if (chatId == null) {
          flowOf(UiState.Success(emptyList()))
        } else {
          repository
            .observeMessages(chatId, currentUserId)
            .map<List<ChatMessage>, UiState<List<ChatMessage>>> { UiState.Success(it) }
            .catch { error ->
              val firestoreError =
                generateSequence(error) { it.cause }
                  .filterIsInstance<FirebaseFirestoreException>()
                  .firstOrNull()
              if (firestoreError == null && error is CancellationException) throw error
              val rootError = firestoreError ?: error
              Log.w(TAG, "Error observing messages", rootError)
              emit(UiState.Error(rootError.message ?: "Xabarlarni yuklashda xatolik"))
            }
        }
      }
      .stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(STOP_TIMEOUT_MILLIS),
        initialValue = UiState.Loading,
      )

  init {
    viewModelScope.launch {
      repository.ensureDirectoryEntry(currentUserDisplayName).onFailure { error ->
        Log.w(TAG, "Failed to register directory code", error)
      }
    }
  }

  fun clearConnectError() {
    _connectError.value = null
  }

  fun clearSendError() {
    _sendError.value = null
  }

  fun openChat(chatId: String) {
    _sendError.value = null
    _activeChatId.value = chatId
  }

  fun closeChat() {
    _sendError.value = null
    _activeChatId.value = null
  }

  fun connectByCode(rawCode: String, onOpened: () -> Unit = {}) {
    val cleanCode = rawCode.trim().uppercase()
    if (cleanCode.length < 4) {
      _connectError.value = "Iltimos, to‘liq ulanish kodini kiriting (masalan, DL8K2M)."
      return
    }
    viewModelScope.launch {
      _connectInProgress.value = true
      _connectError.value = null
      val lookupResult = repository.findUserByCode(cleanCode)
      lookupResult
        .onSuccess { entry ->
          if (entry == null) {
            _connectError.value = "“$cleanCode” kodli foydalanuvchi topilmadi."
            _connectInProgress.value = false
          } else {
            val chatResult =
              repository.startOrOpenChat(
                peerUserId = entry.userId,
                peerDisplayName = entry.displayName,
                myDisplayName = currentUserDisplayName,
              )
            _connectInProgress.value = false
            chatResult
              .onSuccess { chatId ->
                _activeChatId.value = chatId
                onOpened()
              }
              .onFailure { err ->
                _connectError.value = err.localizedMessage ?: "Suhbat ochishda xatolik yuz berdi."
              }
          }
        }
        .onFailure { err ->
          _connectInProgress.value = false
          _connectError.value = err.localizedMessage ?: "Kod tekshirishda xatolik yuz berdi."
        }
    }
  }

  fun startSelfTestChat() {
    viewModelScope.launch {
      _connectInProgress.value = true
      _connectError.value = null
      val result =
        repository.startOrOpenChat(
          peerUserId = currentUserId,
          peerDisplayName = currentUserDisplayName,
          myDisplayName = currentUserDisplayName,
        )
      _connectInProgress.value = false
      result
        .onSuccess { chatId -> _activeChatId.value = chatId }
        .onFailure { err ->
          _connectError.value = err.localizedMessage ?: "Suhbat ochishda xatolik."
        }
    }
  }

  fun sendMessage(text: String, onSent: () -> Unit = {}) {
    val chatId = _activeChatId.value ?: return
    val cleanText = text.trim()
    if (cleanText.isEmpty()) return

    val roomMembers =
      activeChatRoom.value?.memberUids?.takeIf { it.isNotEmpty() }
        ?: if (chatId.startsWith("self_")) {
          listOf(currentUserId)
        } else {
          chatId.split("_").filter { it.isNotBlank() }
        }

    viewModelScope.launch {
      _isSending.value = true
      _sendError.value = null
      val result =
        repository.sendMessage(
          chatId = chatId,
          memberUids = roomMembers,
          senderName = currentUserDisplayName,
          text = cleanText,
        )
      _isSending.value = false
      result
        .onSuccess { onSent() }
        .onFailure { err ->
          _sendError.value = err.localizedMessage ?: "Xabar yuborib bo‘lmadi."
        }
    }
  }

  private companion object {
    const val TAG = "ChatViewModel"
    const val STOP_TIMEOUT_MILLIS = 5000L
  }
}
