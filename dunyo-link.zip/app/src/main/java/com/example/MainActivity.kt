package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.animation.Crossfade
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.key
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.ui.platform.LocalContext
import androidx.credentials.CredentialManager
import androidx.lifecycle.ViewModelProvider.AndroidViewModelFactory.Companion.APPLICATION_KEY
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.lifecycle.viewmodel.initializer
import androidx.lifecycle.viewmodel.viewModelFactory
import com.example.auth.attemptAutoSignIn
import com.example.auth.authStateFlow
import com.example.auth.signOut
import com.example.data.repository.ChatRepository
import com.example.ui.auth.SignInScreen
import com.example.ui.chat.ChatDetailScreen
import com.example.ui.chat.ChatViewModel
import com.example.ui.chat.ChatsScreen
import com.example.ui.theme.DunyoLinkTheme
import com.google.firebase.Firebase
import com.google.firebase.auth.auth
import com.google.firebase.firestore.FirebaseFirestore

class MainActivity : ComponentActivity() {
  override fun onCreate(savedInstanceState: Bundle?) {
    super.onCreate(savedInstanceState)
    enableEdgeToEdge()
    setContent {
      DunyoLinkTheme {
        DunyoLinkApp()
      }
    }
  }
}

@Composable
fun DunyoLinkApp() {
  val auth = Firebase.auth
  val currentUser by auth.authStateFlow().collectAsStateWithLifecycle(initialValue = auth.currentUser)

  val context = LocalContext.current
  val coroutineScope = rememberCoroutineScope()
  val credentialManager = remember(context) { CredentialManager.create(context) }

  LaunchedEffect(Unit) {
    if (auth.currentUser == null) {
      attemptAutoSignIn(
        context = context,
        credentialManager = credentialManager,
        onAuthSuccess = {},
        onUnauthenticated = {},
        scope = coroutineScope,
      )
    }
  }

  val user = currentUser
  if (user == null) {
    SignInScreen(onAuthSuccess = {})
  } else {
    val uid = user.uid
    val displayName = user.displayName?.takeIf { it.isNotBlank() } ?: "Foydalanuvchi"
    key(uid) {
      val chatViewModel: ChatViewModel =
        viewModel(
          key = uid,
          factory =
            viewModelFactory {
              initializer {
                val app =
                  checkNotNull(this[APPLICATION_KEY]) {
                    "APPLICATION_KEY missing from CreationExtras"
                  }
                val databaseId = app.getString(R.string.firestore_database_id)
                val db = FirebaseFirestore.getInstance(databaseId)
                ChatViewModel(
                  repository = ChatRepository(db, Firebase.auth),
                  currentUserId = uid,
                  currentUserDisplayName = displayName,
                )
              }
            },
        )

      val activeChatId by chatViewModel.activeChatId.collectAsStateWithLifecycle()

      Crossfade(targetState = activeChatId, label = "chat_navigation") { chatId ->
        if (chatId == null) {
          ChatsScreen(
            viewModel = chatViewModel,
            onSignOut = {
              signOut(
                credentialManager = credentialManager,
                scope = coroutineScope,
              )
            },
          )
        } else {
          ChatDetailScreen(
            viewModel = chatViewModel,
            onBack = { chatViewModel.closeChat() },
          )
        }
      }
    }
  }
}
