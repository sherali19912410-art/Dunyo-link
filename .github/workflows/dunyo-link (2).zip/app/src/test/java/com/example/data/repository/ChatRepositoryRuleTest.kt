package com.example.data.repository

import com.example.base.FirestoreEmulatorTestBase
import com.google.firebase.firestore.FirebaseFirestoreException
import java.util.UUID
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.runBlocking
import kotlinx.coroutines.tasks.await
import kotlinx.coroutines.withTimeout
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Assert.fail
import org.junit.Test

class ChatRepositoryRuleTest : FirestoreEmulatorTestBase() {

    @Test
    fun ensureUserProfile_twoUsersConnectAndExchangeRealTimeMessages() = runBlocking {
        val runSuffix = UUID.randomUUID().toString().take(6)
        val aliEmail = "ali-$runSuffix@dunyolink.test"
        val bobEmail = "bob-$runSuffix@dunyolink.test"
        val charlieEmail = "charlie-$runSuffix@dunyolink.test"

        // 1. Ali signs in and creates profile + link code
        val aliUid = signInTestUser(aliEmail)
        val aliRepo = ChatRepository(firestore, auth)
        val aliProfile = withTimeout(DEFAULT_TIMEOUT_MS) { aliRepo.ensureUserProfile("Ali") }
        assertTrue(aliProfile.linkCode.length == 6)
        assertEquals(aliUid, aliProfile.userId)

        // 2. Bobur signs in and connects to Ali via link code
        val bobUid = signInTestUser(bobEmail)
        val bobRepo = ChatRepository(firestore, auth)
        withTimeout(DEFAULT_TIMEOUT_MS) { bobRepo.ensureUserProfile("Bobur") }

        val chatIdResult =
            withTimeout(DEFAULT_TIMEOUT_MS) { bobRepo.connectByLinkCode(aliProfile.linkCode) }
        assertTrue(
            "Expected connectByLinkCode to succeed, but failed: ${chatIdResult.exceptionOrNull()}",
            chatIdResult.isSuccess,
        )
        val chatId = chatIdResult.getOrThrow()

        // 3. Bobur sends a message
        val sortedIds = listOf(aliUid, bobUid).sorted()
        val msgResult =
            withTimeout(DEFAULT_TIMEOUT_MS) {
                bobRepo.sendMessage(
                    chatId = chatId,
                    participantIds = sortedIds,
                    senderName = "Bobur",
                    text = "Assalomu alaykum, Ali!",
                )
            }
        assertTrue("Expected sendMessage to succeed", msgResult.isSuccess)

        // 4. Ali observes chat and message in real time
        signInTestUser(aliEmail)
        val aliRepoAgain = ChatRepository(firestore, auth)
        val chats =
            withTimeout(FLOW_TIMEOUT_MS) {
                aliRepoAgain.observeChats(aliUid).first { list -> list.any { it.id == chatId } }
            }
        assertTrue(chats.any { it.id == chatId && it.lastMessageText == "Assalomu alaykum, Ali!" })

        val messages =
            withTimeout(FLOW_TIMEOUT_MS) {
                aliRepoAgain.observeMessages(chatId, aliUid).first { list ->
                    list.any { it.text == "Assalomu alaykum, Ali!" }
                }
            }
        assertEquals(1, messages.count { it.text == "Assalomu alaykum, Ali!" })

        // 5. Third user (Charlie) cannot read the chat directly
        signInTestUser(charlieEmail)
        try {
            withTimeout(DEFAULT_TIMEOUT_MS) {
                firestore.collection("chats").document(chatId).get().await()
            }
            fail("Expected PERMISSION_DENIED for third-party user")
        } catch (e: Exception) {
            val firestoreEx = e.unwrapFirestoreException()
            assertNotNull("Expected FirebaseFirestoreException, got $e", firestoreEx)
            assertEquals(FirebaseFirestoreException.Code.PERMISSION_DENIED, firestoreEx?.code)
        }
    }

    @Test
    fun observeChats_unauthenticatedUser_failsWithPermissionDenied() = runBlocking {
        auth.signOut()
        val repo = ChatRepository(firestore, auth)
        try {
            withTimeout(FLOW_TIMEOUT_MS) { repo.observeChats("unauth_uid").first() }
            fail("Expected unauthenticated observeChats to fail")
        } catch (e: IllegalStateException) {
            assertTrue(e.message?.contains("Google") == true)
        }

        // Also test direct Firestore query when signed out hits PERMISSION_DENIED
        try {
            withTimeout(DEFAULT_TIMEOUT_MS) { firestore.collection("chats").get().await() }
            fail("Expected PERMISSION_DENIED for unauthenticated Firestore query")
        } catch (e: Exception) {
            val firestoreEx = e.unwrapFirestoreException()
            assertNotNull("Expected FirebaseFirestoreException, got $e", firestoreEx)
            assertEquals(FirebaseFirestoreException.Code.PERMISSION_DENIED, firestoreEx?.code)
        }
    }

    private companion object {
        const val DEFAULT_TIMEOUT_MS = 8000L
        const val FLOW_TIMEOUT_MS = 5000L
    }
}
