package com.example.ui.auth

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class PhoneAuthStateTest {

    @Test
    fun countryDirectory_containsUzbekistanGermanyPoland() {
        val codes = CountryDirectory.all.map { it.dialCode }
        assertTrue(codes.contains("+998"))
        assertTrue(codes.contains("+49"))
        assertTrue(codes.contains("+48"))
    }

    @Test
    fun phoneAuthUiState_buildsE164AndValidatesLength() {
        val uzState =
            PhoneAuthUiState(
                selectedCountry = CountryDirectory.uzbekistan,
                phoneDigits = "901234567",
            )
        assertEquals("+998901234567", uzState.fullE164Phone)
        assertTrue(uzState.isPhoneValid)

        val shortState = uzState.copy(phoneDigits = "90123")
        assertFalse(shortState.isPhoneValid)

        val deCountry = CountryDirectory.all.first { it.iso == "DE" }
        val deState =
            PhoneAuthUiState(
                selectedCountry = deCountry,
                phoneDigits = "15123456789",
            )
        assertEquals("+4915123456789", deState.fullE164Phone)
        assertTrue(deState.isPhoneValid)
    }
}
