package com.example

import android.net.Uri
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.key
import androidx.lifecycle.ViewModelProvider.AndroidViewModelFactory.Companion.APPLICATION_KEY
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.lifecycle.viewmodel.initializer
import androidx.lifecycle.viewmodel.viewModelFactory
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import androidx.navigation.navArgument
import com.example.data.repository.ChatRepository
import com.example.ui.auth.AuthScreen
import com.example.ui.auth.signOutUser
import com.example.ui.screens.ChatDetailScreen
import com.example.ui.screens.ChatsHomeScreen
import com.example.ui.theme.DunyoLinkTheme
import com.example.ui.viewmodel.ChatDetailViewModel
import com.example.ui.viewmodel.ChatsViewModel
import com.google.firebase.Firebase
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.FirebaseUser
import com.google.firebase.auth.auth
import com.google.firebase.firestore.FirebaseFirestore
import kotlinx.coroutines.channels.awaitClose
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.callbackFlow

const val ROUTE_CHATS = "chats"
const val ROUTE_CHAT_DETAIL = "chat/{chatId}"

internal fun FirebaseAuth.authStateFlow(): Flow<FirebaseUser?> = callbackFlow {
    val listener = FirebaseAuth.AuthStateListener { auth -> trySend(auth.currentUser) }
    addAuthStateListener(listener)
    awaitClose { removeAuthStateListener(listener) }
}

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            DunyoLinkTheme {
                AppNavigation()
            }
        }
    }
}

@Composable
fun AppNavigation(auth: FirebaseAuth = Firebase.auth) {
    val currentUser by
        auth.authStateFlow().collectAsStateWithLifecycle(initialValue = auth.currentUser)
    val user = currentUser

    if (user == null) {
        AuthScreen()
    } else {
        val uid = user.uid
        val displayName = user.displayName

        key(uid) {
            val navController = rememberNavController()
            val chatsViewModel: ChatsViewModel =
                viewModel(
                    key = "chats_$uid",
                    factory =
                        viewModelFactory {
                            initializer {
                                val app =
                                    checkNotNull(this[APPLICATION_KEY]) {
                                        "APPLICATION_KEY missing from CreationExtras"
                                    }
                                val databaseId = app.getString(R.string.firestore_database_id)
                                val db = FirebaseFirestore.getInstance(databaseId)
                                ChatsViewModel(
                                    repository = ChatRepository(db, auth),
                                    currentUserId = uid,
                                    initialDisplayName = displayName,
                                )
                            }
                        },
                )

            NavHost(navController = navController, startDestination = ROUTE_CHATS) {
                composable(ROUTE_CHATS) {
                    ChatsHomeScreen(
                        viewModel = chatsViewModel,
                        currentUserId = uid,
                        onOpenChat = { chatId ->
                            navController.navigate("chat/${Uri.encode(chatId)}")
                        },
                        onSignOut = { signOutUser() },
                    )
                }

                composable(
                    route = ROUTE_CHAT_DETAIL,
                    arguments = listOf(navArgument("chatId") { type = NavType.StringType }),
                ) { backStackEntry ->
                    val chatId = backStackEntry.arguments?.getString("chatId").orEmpty()
                    val detailViewModel: ChatDetailViewModel =
                        viewModel(
                            key = "chat_${uid}_$chatId",
                            factory =
                                viewModelFactory {
                                    initializer {
                                        val app =
                                            checkNotNull(this[APPLICATION_KEY]) {
                                                "APPLICATION_KEY missing from CreationExtras"
                                            }
                                        val databaseId =
                                            app.getString(R.string.firestore_database_id)
                                        val db = FirebaseFirestore.getInstance(databaseId)
                                        ChatDetailViewModel(
                                            repository = ChatRepository(db, auth),
                                            currentUserId = uid,
                                            chatId = chatId,
                                            fallbackDisplayName = "Foydalanuvchi",
                                        )
                                    }
                                },
                        )

                    ChatDetailScreen(
                        viewModel = detailViewModel,
                        currentUserId = uid,
                        onNavigateBack = { navController.popBackStack() },
                    )
                }
            }
        }
    }
}
