package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Brand Emerald-Teal & Warm Amber Palette (Light)
val TealPrimaryLight = Color(0xFF0B6E68)
val OnTealPrimaryLight = Color(0xFFFFFFFF)
val TealPrimaryContainerLight = Color(0xFFC5F4E9)
val OnTealPrimaryContainerLight = Color(0xFF00211E)

val AmberSecondaryLight = Color(0xFFB96E0B)
val OnAmberSecondaryLight = Color(0xFFFFFFFF)
val AmberSecondaryContainerLight = Color(0xFFFFE5BD)
val OnAmberSecondaryContainerLight = Color(0xFF3A2000)

val HorizonTertiaryLight = Color(0xFF285C87)
val OnHorizonTertiaryLight = Color(0xFFFFFFFF)
val HorizonTertiaryContainerLight = Color(0xFFD2E7FF)
val OnHorizonTertiaryContainerLight = Color(0xFF001D35)

val MintBackgroundLight = Color(0xFFF3F8F7)
val MintSurfaceLight = Color(0xFFFFFFFF)
val MintSurfaceContainerLight = Color(0xFFEAF2F0)
val MintSurfaceVariantLight = Color(0xFFE0ECE9)
val OnMintSurfaceLight = Color(0xFF0E2321)
val OnMintSurfaceVariantLight = Color(0xFF435D5A)
val MintOutlineLight = Color(0xFF718C88)
val MintOutlineVariantLight = Color(0xFFC4D7D4)
val ErrorLight = Color(0xFFBA1A1A)
val OnErrorLight = Color(0xFFFFFFFF)

// Brand Emerald-Teal & Warm Amber Palette (Dark)
val TealPrimaryDark = Color(0xFF4ADBC0)
val OnTealPrimaryDark = Color(0xFF00382F)
val TealPrimaryContainerDark = Color(0xFF005147)
val OnTealPrimaryContainerDark = Color(0xFFA8F5E5)

val AmberSecondaryDark = Color(0xFFFBBF24)
val OnAmberSecondaryDark = Color(0xFF3E2500)
val AmberSecondaryContainerDark = Color(0xFF5A3900)
val OnAmberSecondaryContainerDark = Color(0xFFFFE3AC)

val HorizonTertiaryDark = Color(0xFF9ECAFF)
val OnHorizonTertiaryDark = Color(0xFF003258)
val HorizonTertiaryContainerDark = Color(0xFF00497D)
val OnHorizonTertiaryContainerDark = Color(0xFFD2E7FF)

val TealBackgroundDark = Color(0xFF071617)
val TealSurfaceDark = Color(0xFF0D2123)
val TealSurfaceContainerDark = Color(0xFF132C2F)
val TealSurfaceVariantDark = Color(0xFF1B3A3E)
val OnTealSurfaceDark = Color(0xFFE2F1EF)
val OnTealSurfaceVariantDark = Color(0xFF9FBCB8)
val TealOutlineDark = Color(0xFF6A8884)
val TealOutlineVariantDark = Color(0xFF25474B)
val ErrorDark = Color(0xFFFFB4AB)
val OnErrorDark = Color(0xFF690005)

// Chat-specific semantic tokens
val LiveGreen = Color(0xFF22C55E)
val AvatarPalette =
    listOf(
        Color(0xFF0B6E68),
        Color(0xFFD97706),
        Color(0xFF2563EB),
        Color(0xFF059669),
        Color(0xFFDB2777),
        Color(0xFF7C3AED),
        Color(0xFF0891B2),
        Color(0xFFDC2626),
    )
