package com.example.data.repository

import android.content.Context
import com.example.R
import com.example.data.OperationType
import com.example.data.handleFirestoreError
import com.example.data.model.ChatMessage
import com.example.data.model.ChatRoom
import com.example.data.model.LinkCodeEntry
import com.example.data.model.UserProfile
import com.google.firebase.Firebase
import com.google.firebase.Timestamp
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.auth
import com.google.firebase.firestore.DocumentSnapshot
import com.google.firebase.firestore.FieldValue
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.FirebaseFirestoreException
import com.google.firebase.firestore.snapshots
import java.security.SecureRandom
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.emitAll
import kotlinx.coroutines.flow.flow
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.tasks.await

class ChatRepository(
    private val db: FirebaseFirestore,
    private val auth: FirebaseAuth = Firebase.auth,
) {
    constructor(context: Context) : this(
        db =
            FirebaseFirestore.getInstance(
                context.applicationContext.getString(R.string.firestore_database_id)
            ),
        auth = Firebase.auth,
    )

    private fun requireUserId(): String {
        return auth.currentUser?.uid
            ?: throw IllegalStateException(
                "Firestore bilan ishlash uchun avval Google hisobi orqali tizimga kiring."
            )
    }

    suspend fun ensureUserProfile(defaultDisplayName: String? = null): UserProfile {
        val uid = requireUserId()
        val userRef = db.collection(COLLECTION_USERS).document(uid)
        try {
            val existing = userRef.get().await()
            val parsed =
                existing.toObject(
                    UserProfile::class.java,
                    DocumentSnapshot.ServerTimestampBehavior.ESTIMATE,
                )
            if (existing.exists() && parsed != null && parsed.linkCode.isNotBlank()) {
                return parsed
            }
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.GET, userRef.path, auth)
            throw e
        }

        val cleanName =
            defaultDisplayName?.trim()?.takeIf { it.isNotEmpty() }?.take(60)
                ?: auth.currentUser?.displayName?.trim()?.takeIf { it.isNotEmpty() }?.take(60)
                ?: "Foydalanuvchi ${uid.takeLast(4).uppercase()}"
        val colorIndex = (uid.hashCode().toLong() and 0x7FFFFFFFL) % AVATAR_PALETTE_SIZE

        repeat(MAX_CODE_ATTEMPTS) {
            val candidateCode = generateLinkCode()
            val codeRef = db.collection(COLLECTION_LINK_CODES).document(candidateCode)
            val existingCode =
                try {
                    codeRef.get().await()
                } catch (e: CancellationException) {
                    throw e
                } catch (e: Exception) {
                    handleFirestoreError(e, OperationType.GET, codeRef.path, auth)
                    throw e
                }

            if (!existingCode.exists()) {
                val userPayload =
                    mapOf(
                        "userId" to uid,
                        "displayName" to cleanName,
                        "linkCode" to candidateCode,
                        "avatarColorIndex" to colorIndex,
                        "createdAt" to FieldValue.serverTimestamp(),
                        "updatedAt" to FieldValue.serverTimestamp(),
                    )
                val codePayload =
                    mapOf(
                        "code" to candidateCode,
                        "uid" to uid,
                        "displayName" to cleanName,
                        "avatarColorIndex" to colorIndex,
                        "createdAt" to FieldValue.serverTimestamp(),
                        "updatedAt" to FieldValue.serverTimestamp(),
                    )

                try {
                    db.runBatch { batch ->
                            batch.set(userRef, userPayload)
                            batch.set(codeRef, codePayload)
                        }
                        .await()
                    val created = userRef.get().await()
                    return created.toObject(
                        UserProfile::class.java,
                        DocumentSnapshot.ServerTimestampBehavior.ESTIMATE,
                    )
                        ?: UserProfile(
                            id = uid,
                            userId = uid,
                            displayName = cleanName,
                            linkCode = candidateCode,
                            avatarColorIndex = colorIndex,
                        )
                } catch (e: CancellationException) {
                    throw e
                } catch (e: Exception) {
                    handleFirestoreError(e, OperationType.WRITE, userRef.path, auth)
                    throw e
                }
            }
        }
        throw IllegalStateException("Unikal Link kodi yaratib bo‘lmadi. Qaytadan urinib ko‘ring.")
    }

    fun observeUserProfile(userId: String): Flow<UserProfile?> = flow {
        val uid = requireUserId()
        val docRef = db.collection(COLLECTION_USERS).document(userId)
        emitAll(
            docRef
                .snapshots()
                .map { snapshot ->
                    snapshot.toObject(
                        UserProfile::class.java,
                        DocumentSnapshot.ServerTimestampBehavior.ESTIMATE,
                    )
                }
                .catch { error ->
                    logStreamError(error, OperationType.GET, docRef.path, uid)
                    throw error
                }
        )
    }

    suspend fun updateDisplayName(newName: String, linkCode: String) {
        val uid = requireUserId()
        val cleanName = newName.trim()
        require(cleanName.length in 1..60) {
            "Ism 1 dan 60 tagacha belgidan iborat bo‘lishi kerak."
        }
        val userRef = db.collection(COLLECTION_USERS).document(uid)
        val codeRef = db.collection(COLLECTION_LINK_CODES).document(linkCode)
        try {
            db.runBatch { batch ->
                    batch.update(
                        userRef,
                        mapOf(
                            "displayName" to cleanName,
                            "updatedAt" to FieldValue.serverTimestamp(),
                        ),
                    )
                    batch.update(
                        codeRef,
                        mapOf(
                            "displayName" to cleanName,
                            "updatedAt" to FieldValue.serverTimestamp(),
                        ),
                    )
                }
                .await()
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.UPDATE, userRef.path, auth)
            throw e
        }
    }

    suspend fun connectByLinkCode(rawCode: String): Result<String> {
        val uid = requireUserId()
        val normalizedCode =
            rawCode.trim().uppercase().replace("-", "").replace(" ", "")
        if (!LINK_CODE_REGEX.matches(normalizedCode)) {
            return Result.failure(
                IllegalArgumentException(
                    "Link kodi 6 ta harf yoki raqamdan iborat bo‘lishi kerak (masalan: A7K9M2)."
                )
            )
        }

        val codeRef = db.collection(COLLECTION_LINK_CODES).document(normalizedCode)
        val partnerEntry =
            try {
                val snapshot = codeRef.get().await()
                if (!snapshot.exists()) {
                    return Result.failure(
                        NoSuchElementException(
                            "Bunday Link kodi topilmadi. Do‘stingiz kodini tekshirib qayta kiriting."
                        )
                    )
                }
                snapshot.toObject(
                    LinkCodeEntry::class.java,
                    DocumentSnapshot.ServerTimestampBehavior.ESTIMATE,
                )
                    ?: return Result.failure(
                        IllegalStateException("Foydalanuvchi ma’lumotini o‘qib bo‘lmadi.")
                    )
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                handleFirestoreError(e, OperationType.GET, codeRef.path, auth)
                return Result.failure(e)
            }

        if (partnerEntry.uid == uid) {
            return Result.failure(
                IllegalArgumentException(
                    "Bu sizning o‘z kodingiz. Suhbat boshlash uchun boshqa foydalanuvchi kodini kiriting."
                )
            )
        }

        val myProfile = ensureUserProfile()
        val sortedIds = listOf(uid, partnerEntry.uid).sorted()
        val chatId = "${sortedIds[0]}_${sortedIds[1]}"
        val p1Name =
            if (sortedIds[0] == uid) myProfile.displayName else partnerEntry.displayName
        val p2Name =
            if (sortedIds[1] == uid) myProfile.displayName else partnerEntry.displayName

        val chatRef = db.collection(COLLECTION_CHATS).document(chatId)
        return try {
            val existingChat = chatRef.get().await()
            if (!existingChat.exists()) {
                val chatPayload =
                    mapOf(
                        "participantIds" to sortedIds,
                        "participantOneId" to sortedIds[0],
                        "participantOneName" to sanitizeDisplayName(p1Name),
                        "participantTwoId" to sortedIds[1],
                        "participantTwoName" to sanitizeDisplayName(p2Name),
                        "lastMessageText" to "",
                        "lastMessageSenderId" to "",
                        "lastMessageAt" to FieldValue.serverTimestamp(),
                        "createdAt" to FieldValue.serverTimestamp(),
                        "updatedAt" to FieldValue.serverTimestamp(),
                    )
                chatRef.set(chatPayload).await()
            }
            Result.success(chatId)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.CREATE, chatRef.path, auth)
            Result.failure(e)
        }
    }

    fun observeChats(userId: String): Flow<List<ChatRoom>> = flow {
        val uid = requireUserId()
        val path = COLLECTION_CHATS
        emitAll(
            db.collection(COLLECTION_CHATS)
                .whereArrayContains("participantIds", userId)
                .snapshots()
                .map { snapshot ->
                    snapshot
                        .toObjects(
                            ChatRoom::class.java,
                            DocumentSnapshot.ServerTimestampBehavior.ESTIMATE,
                        )
                        .sortedByDescending {
                            it.lastMessageAt ?: it.createdAt ?: Timestamp(0, 0)
                        }
                }
                .catch { error ->
                    logStreamError(error, OperationType.LIST, path, uid)
                    throw error
                }
        )
    }

    fun observeChatRoom(chatId: String): Flow<ChatRoom?> = flow {
        val uid = requireUserId()
        val docRef = db.collection(COLLECTION_CHATS).document(chatId)
        emitAll(
            docRef
                .snapshots()
                .map { snapshot ->
                    snapshot.toObject(
                        ChatRoom::class.java,
                        DocumentSnapshot.ServerTimestampBehavior.ESTIMATE,
                    )
                }
                .catch { error ->
                    logStreamError(error, OperationType.GET, docRef.path, uid)
                    throw error
                }
        )
    }

    fun observeMessages(chatId: String, userId: String): Flow<List<ChatMessage>> = flow {
        val uid = requireUserId()
        val path = "$COLLECTION_CHATS/$chatId/$COLLECTION_MESSAGES"
        emitAll(
            db.collection(COLLECTION_CHATS)
                .document(chatId)
                .collection(COLLECTION_MESSAGES)
                .whereArrayContains("participantIds", userId)
                .snapshots()
                .map { snapshot ->
                    snapshot
                        .toObjects(
                            ChatMessage::class.java,
                            DocumentSnapshot.ServerTimestampBehavior.ESTIMATE,
                        )
                        .sortedWith(
                            compareBy<ChatMessage> { it.createdAt ?: Timestamp.now() }
                                .thenBy { it.id }
                        )
                }
                .catch { error ->
                    logStreamError(error, OperationType.LIST, path, uid)
                    throw error
                }
        )
    }

    suspend fun sendMessage(
        chatId: String,
        participantIds: List<String>,
        senderName: String,
        text: String,
    ): Result<String> {
        val uid = requireUserId()
        val trimmedText = text.trim()
        if (trimmedText.isEmpty()) {
            return Result.failure(IllegalArgumentException("Bo‘sh xabar yuborib bo‘lmaydi."))
        }
        val safeText = trimmedText.take(2000)
        val safeSenderName = sanitizeDisplayName(senderName)
        val sortedParticipants = participantIds.sorted()

        val chatRef = db.collection(COLLECTION_CHATS).document(chatId)
        val messageRef = chatRef.collection(COLLECTION_MESSAGES).document()

        val messagePayload =
            mapOf(
                "senderId" to uid,
                "senderName" to safeSenderName,
                "text" to safeText,
                "participantIds" to sortedParticipants,
                "createdAt" to FieldValue.serverTimestamp(),
            )
        val chatUpdatePayload =
            mapOf(
                "lastMessageText" to safeText.take(1000),
                "lastMessageSenderId" to uid,
                "lastMessageAt" to FieldValue.serverTimestamp(),
                "updatedAt" to FieldValue.serverTimestamp(),
            )

        return try {
            db.runBatch { batch ->
                    batch.set(messageRef, messagePayload)
                    batch.update(chatRef, chatUpdatePayload)
                }
                .await()
            Result.success(messageRef.id)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.WRITE, messageRef.path, auth)
            Result.failure(e)
        }
    }

    private fun logStreamError(
        error: Throwable,
        operationType: OperationType,
        path: String,
        expectedUid: String,
    ) {
        val firestoreError =
            generateSequence(error) { it.cause }
                .filterIsInstance<FirebaseFirestoreException>()
                .firstOrNull()
        if (firestoreError == null && error is CancellationException) return
        val exceptionToLog = firestoreError ?: (error as? Exception)
        if (exceptionToLog != null && auth.currentUser?.uid == expectedUid) {
            handleFirestoreError(exceptionToLog, operationType, path, auth)
        }
    }

    private fun sanitizeDisplayName(name: String?): String {
        val trimmed = name?.trim().orEmpty()
        return if (trimmed.isEmpty()) "Foydalanuvchi" else trimmed.take(60)
    }

    private fun generateLinkCode(): String {
        return buildString(6) {
            repeat(6) {
                append(CODE_ALPHABET[random.nextInt(CODE_ALPHABET.length)])
            }
        }
    }

    companion object {
        const val COLLECTION_USERS = "users"
        const val COLLECTION_LINK_CODES = "link_codes"
        const val COLLECTION_CHATS = "chats"
        const val COLLECTION_MESSAGES = "messages"
        private const val AVATAR_PALETTE_SIZE = 8L
        private const val MAX_CODE_ATTEMPTS = 6
        private const val CODE_ALPHABET = "23456789ABCDEFGHJKMNPQRSTUVWXYZ"
        private val LINK_CODE_REGEX = Regex("^[A-Z0-9]{6,12}$")
        private val random = SecureRandom()
    }
}
