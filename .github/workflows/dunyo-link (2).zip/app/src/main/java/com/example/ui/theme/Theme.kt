package com.example.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable

private val DarkColorScheme =
    darkColorScheme(
        primary = TealPrimaryDark,
        onPrimary = OnTealPrimaryDark,
        primaryContainer = TealPrimaryContainerDark,
        onPrimaryContainer = OnTealPrimaryContainerDark,
        secondary = AmberSecondaryDark,
        onSecondary = OnAmberSecondaryDark,
        secondaryContainer = AmberSecondaryContainerDark,
        onSecondaryContainer = OnAmberSecondaryContainerDark,
        tertiary = HorizonTertiaryDark,
        onTertiary = OnHorizonTertiaryDark,
        tertiaryContainer = HorizonTertiaryContainerDark,
        onTertiaryContainer = OnHorizonTertiaryContainerDark,
        background = TealBackgroundDark,
        onBackground = OnTealSurfaceDark,
        surface = TealSurfaceDark,
        onSurface = OnTealSurfaceDark,
        surfaceContainer = TealSurfaceContainerDark,
        surfaceVariant = TealSurfaceVariantDark,
        onSurfaceVariant = OnTealSurfaceVariantDark,
        outline = TealOutlineDark,
        outlineVariant = TealOutlineVariantDark,
        error = ErrorDark,
        onError = OnErrorDark,
    )

private val LightColorScheme =
    lightColorScheme(
        primary = TealPrimaryLight,
        onPrimary = OnTealPrimaryLight,
        primaryContainer = TealPrimaryContainerLight,
        onPrimaryContainer = OnTealPrimaryContainerLight,
        secondary = AmberSecondaryLight,
        onSecondary = OnAmberSecondaryLight,
        secondaryContainer = AmberSecondaryContainerLight,
        onSecondaryContainer = OnAmberSecondaryContainerLight,
        tertiary = HorizonTertiaryLight,
        onTertiary = OnHorizonTertiaryLight,
        tertiaryContainer = HorizonTertiaryContainerLight,
        onTertiaryContainer = OnHorizonTertiaryContainerLight,
        background = MintBackgroundLight,
        onBackground = OnMintSurfaceLight,
        surface = MintSurfaceLight,
        onSurface = OnMintSurfaceLight,
        surfaceContainer = MintSurfaceContainerLight,
        surfaceVariant = MintSurfaceVariantLight,
        onSurfaceVariant = OnMintSurfaceVariantLight,
        outline = MintOutlineLight,
        outlineVariant = MintOutlineVariantLight,
        error = ErrorLight,
        onError = OnErrorLight,
    )

@Composable
fun DunyoLinkTheme(
    darkTheme: Boolean = isSystemInDarkTheme(),
    content: @Composable () -> Unit,
) {
    val colorScheme = if (darkTheme) DarkColorScheme else LightColorScheme

    MaterialTheme(
        colorScheme = colorScheme,
        typography = DunyoTypography,
        content = content,
    )
}
