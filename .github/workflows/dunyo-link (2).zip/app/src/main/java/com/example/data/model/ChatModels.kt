package com.example.data.model

import com.google.firebase.Timestamp
import com.google.firebase.firestore.DocumentId
import com.google.firebase.firestore.IgnoreExtraProperties
import com.google.firebase.firestore.ServerTimestamp

@IgnoreExtraProperties
data class UserProfile(
    @DocumentId val id: String = "",
    val userId: String = "",
    val displayName: String = "",
    val linkCode: String = "",
    val avatarColorIndex: Long = 0L,
    @ServerTimestamp val createdAt: Timestamp? = null,
    @ServerTimestamp val updatedAt: Timestamp? = null,
)

@IgnoreExtraProperties
data class LinkCodeEntry(
    @DocumentId val id: String = "",
    val code: String = "",
    val uid: String = "",
    val displayName: String = "",
    val avatarColorIndex: Long = 0L,
    @ServerTimestamp val createdAt: Timestamp? = null,
    @ServerTimestamp val updatedAt: Timestamp? = null,
)

@IgnoreExtraProperties
data class ChatRoom(
    @DocumentId val id: String = "",
    val participantIds: List<String> = emptyList(),
    val participantOneId: String = "",
    val participantOneName: String = "",
    val participantTwoId: String = "",
    val participantTwoName: String = "",
    val lastMessageText: String = "",
    val lastMessageSenderId: String = "",
    @ServerTimestamp val lastMessageAt: Timestamp? = null,
    @ServerTimestamp val createdAt: Timestamp? = null,
    @ServerTimestamp val updatedAt: Timestamp? = null,
) {
    fun partnerId(currentUserId: String): String =
        if (participantOneId == currentUserId) participantTwoId else participantOneId

    fun partnerName(currentUserId: String): String {
        val raw = if (participantOneId == currentUserId) participantTwoName else participantOneName
        return raw.ifBlank { "Foydalanuvchi" }
    }
}

@IgnoreExtraProperties
data class ChatMessage(
    @DocumentId val id: String = "",
    val senderId: String = "",
    val senderName: String = "",
    val text: String = "",
    val participantIds: List<String> = emptyList(),
    @ServerTimestamp val createdAt: Timestamp? = null,
)
