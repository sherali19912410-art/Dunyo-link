package com.example.ui.auth

import android.app.Activity
import android.content.Context
import android.content.ContextWrapper
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawing
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.ArrowDropDown
import androidx.compose.material.icons.rounded.Check
import androidx.compose.material.icons.rounded.Edit
import androidx.compose.material.icons.rounded.Forum
import androidx.compose.material.icons.rounded.Phone
import androidx.compose.material.icons.rounded.Search
import androidx.compose.material.icons.rounded.Sms
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.R
import com.example.ui.theme.JetBrainsMonoFamily
import com.google.firebase.Firebase
import com.google.firebase.auth.auth

private tailrec fun Context.findActivity(): Activity? =
    when (this) {
        is Activity -> this
        is ContextWrapper -> baseContext.findActivity()
        else -> null
    }

fun signOutUser() {
    Firebase.auth.signOut()
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AuthScreen(
    viewModel: PhoneAuthViewModel = viewModel(),
) {
    val uiState by viewModel.uiState.collectAsStateWithLifecycle()
    val context = LocalContext.current
    val activity = remember(context) { context.findActivity() }
    var showCountryPicker by remember { mutableStateOf(false) }

    Box(
        modifier =
            Modifier.fillMaxSize()
                .background(
                    Brush.verticalGradient(
                        colors =
                            listOf(
                                MaterialTheme.colorScheme.background,
                                MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.35f),
                                MaterialTheme.colorScheme.background,
                            )
                    )
                )
                .windowInsetsPadding(WindowInsets.safeDrawing)
                .imePadding()
    ) {
        Column(
            modifier =
                Modifier.fillMaxSize()
                    .widthIn(max = 560.dp)
                    .align(Alignment.Center)
                    .verticalScroll(rememberScrollState())
                    .padding(horizontal = 24.dp, vertical = 20.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.SpaceBetween,
        ) {
            Column(
                horizontalAlignment = Alignment.CenterHorizontally,
                modifier = Modifier.fillMaxWidth(),
            ) {
                Surface(
                    color = MaterialTheme.colorScheme.primaryContainer,
                    shape = RoundedCornerShape(50),
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 14.dp, vertical = 6.dp),
                        verticalAlignment = Alignment.CenterVertically,
                    ) {
                        Icon(
                            imageVector = Icons.Rounded.Forum,
                            contentDescription = null,
                            tint = MaterialTheme.colorScheme.primary,
                            modifier = Modifier.size(16.dp),
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = stringResource(R.string.app_name),
                            style = MaterialTheme.typography.labelLarge,
                            color = MaterialTheme.colorScheme.onPrimaryContainer,
                        )
                    }
                }

                Spacer(modifier = Modifier.height(16.dp))

                Card(
                    shape = RoundedCornerShape(26.dp),
                    elevation = CardDefaults.cardElevation(defaultElevation = 4.dp),
                    modifier = Modifier.fillMaxWidth().height(176.dp),
                ) {
                    Image(
                        painter = painterResource(id = R.drawable.img_chat_hero_1794762129187),
                        contentDescription = stringResource(R.string.app_name),
                        contentScale = ContentScale.Crop,
                        modifier = Modifier.fillMaxSize(),
                    )
                }

                Spacer(modifier = Modifier.height(20.dp))

                Text(
                    text = stringResource(R.string.app_name),
                    style = MaterialTheme.typography.headlineLarge,
                    color = MaterialTheme.colorScheme.onBackground,
                    textAlign = TextAlign.Center,
                )

                Spacer(modifier = Modifier.height(6.dp))

                Text(
                    text = stringResource(R.string.tagline_auth),
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    textAlign = TextAlign.Center,
                )

                Spacer(modifier = Modifier.height(22.dp))

                Surface(
                    color = MaterialTheme.colorScheme.surface,
                    tonalElevation = 2.dp,
                    shadowElevation = 2.dp,
                    shape = RoundedCornerShape(24.dp),
                    modifier = Modifier.fillMaxWidth(),
                ) {
                    when (val step = uiState.step) {
                        is PhoneAuthStep.PhoneEntry,
                        is PhoneAuthStep.SendingCode -> {
                            PhoneEntryCardContent(
                                uiState = uiState,
                                isSending = step is PhoneAuthStep.SendingCode,
                                onOpenCountryPicker = { showCountryPicker = true },
                                onPhoneChanged = viewModel::onPhoneDigitsChanged,
                                onSendSmsClick = {
                                    if (activity != null) {
                                        viewModel.sendVerificationCode(activity, isResend = false)
                                    }
                                },
                            )
                        }

                        is PhoneAuthStep.OtpEntry,
                        is PhoneAuthStep.VerifyingOtp -> {
                            val formattedPhone =
                                if (step is PhoneAuthStep.OtpEntry) step.formattedPhone
                                else (step as PhoneAuthStep.VerifyingOtp).formattedPhone
                            val resendSeconds =
                                (step as? PhoneAuthStep.OtpEntry)?.resendSecondsLeft ?: 0
                            val isVerifying = step is PhoneAuthStep.VerifyingOtp

                            OtpEntryCardContent(
                                formattedPhone = formattedPhone,
                                otpCode = uiState.otpCode,
                                resendSecondsLeft = resendSeconds,
                                isVerifying = isVerifying,
                                errorMessage = uiState.errorMessage,
                                onOtpChanged = viewModel::onOtpChanged,
                                onVerifyClick = viewModel::verifyOtpCode,
                                onResendClick = {
                                    if (activity != null) {
                                        viewModel.sendVerificationCode(activity, isResend = true)
                                    }
                                },
                                onChangePhoneClick = viewModel::changePhoneNumber,
                            )
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(16.dp))
        }
    }

    if (showCountryPicker) {
        CountryPickerBottomSheet(
            selectedCountry = uiState.selectedCountry,
            onSelect = { country ->
                viewModel.selectCountry(country)
                showCountryPicker = false
            },
            onDismiss = { showCountryPicker = false },
        )
    }
}

@Composable
private fun PhoneEntryCardContent(
    uiState: PhoneAuthUiState,
    isSending: Boolean,
    onOpenCountryPicker: () -> Unit,
    onPhoneChanged: (String) -> Unit,
    onSendSmsClick: () -> Unit,
) {
    Column(
        modifier = Modifier.fillMaxWidth().padding(20.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp),
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Icon(
                imageVector = Icons.Rounded.Phone,
                contentDescription = null,
                tint = MaterialTheme.colorScheme.primary,
                modifier = Modifier.size(22.dp),
            )
            Spacer(modifier = Modifier.width(8.dp))
            Text(
                text = stringResource(R.string.phone_auth_title),
                style = MaterialTheme.typography.titleLarge,
                color = MaterialTheme.colorScheme.onSurface,
            )
        }

        Text(
            text = stringResource(R.string.phone_auth_subtitle),
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
        )

        OutlinedButton(
            onClick = onOpenCountryPicker,
            enabled = !isSending,
            shape = RoundedCornerShape(16.dp),
            modifier =
                Modifier.fillMaxWidth()
                    .height(54.dp)
                    .testTag("country_selector_button"),
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween,
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(
                        text = uiState.selectedCountry.flagEmoji,
                        style = MaterialTheme.typography.titleLarge,
                    )
                    Spacer(modifier = Modifier.width(10.dp))
                    Text(
                        text = uiState.selectedCountry.nameUz,
                        style = MaterialTheme.typography.titleMedium,
                        color = MaterialTheme.colorScheme.onSurface,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis,
                    )
                }
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(
                        text = uiState.selectedCountry.dialCode,
                        style =
                            MaterialTheme.typography.titleMedium.copy(
                                fontFamily = JetBrainsMonoFamily
                            ),
                        color = MaterialTheme.colorScheme.primary,
                    )
                    Spacer(modifier = Modifier.width(4.dp))
                    Icon(
                        imageVector = Icons.Rounded.ArrowDropDown,
                        contentDescription = stringResource(R.string.select_country_title),
                        tint = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                }
            }
        }

        OutlinedTextField(
            value = uiState.phoneDigits,
            onValueChange = onPhoneChanged,
            enabled = !isSending,
            label = { Text(text = stringResource(R.string.phone_number_label)) },
            placeholder = { Text(text = uiState.selectedCountry.exampleHint) },
            prefix = {
                Text(
                    text = "${uiState.selectedCountry.dialCode} ",
                    style =
                        MaterialTheme.typography.titleMedium.copy(
                            fontFamily = JetBrainsMonoFamily
                        ),
                    color = MaterialTheme.colorScheme.primary,
                )
            },
            supportingText = {
                if (uiState.phoneDigits.isNotEmpty()) {
                    Text(text = "To‘liq raqam: ${uiState.fullE164Phone}")
                }
            },
            singleLine = true,
            textStyle =
                MaterialTheme.typography.titleMedium.copy(
                    fontFamily = JetBrainsMonoFamily
                ),
            keyboardOptions =
                KeyboardOptions(
                    keyboardType = KeyboardType.Phone,
                    imeAction = ImeAction.Done,
                ),
            keyboardActions =
                KeyboardActions(
                    onDone = { if (uiState.isPhoneValid && !isSending) onSendSmsClick() }
                ),
            shape = RoundedCornerShape(16.dp),
            colors =
                OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = MaterialTheme.colorScheme.primary,
                    unfocusedBorderColor = MaterialTheme.colorScheme.outlineVariant,
                ),
            modifier = Modifier.fillMaxWidth().testTag("phone_number_input"),
        )

        if (uiState.errorMessage != null) {
            ErrorBanner(message = uiState.errorMessage)
        }

        Button(
            onClick = onSendSmsClick,
            enabled = uiState.isPhoneValid && !isSending,
            shape = RoundedCornerShape(18.dp),
            colors =
                ButtonDefaults.buttonColors(
                    containerColor = MaterialTheme.colorScheme.primary,
                    contentColor = MaterialTheme.colorScheme.onPrimary,
                ),
            modifier =
                Modifier.fillMaxWidth()
                    .height(56.dp)
                    .testTag("send_sms_button"),
        ) {
            if (isSending) {
                CircularProgressIndicator(
                    modifier = Modifier.size(22.dp),
                    color = MaterialTheme.colorScheme.onPrimary,
                    strokeWidth = 2.5.dp,
                )
                Spacer(modifier = Modifier.width(10.dp))
                Text(
                    text = stringResource(R.string.sending_sms_label),
                    style = MaterialTheme.typography.labelLarge,
                )
            } else {
                Icon(
                    imageVector = Icons.Rounded.Sms,
                    contentDescription = null,
                    modifier = Modifier.size(20.dp),
                )
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                    text = stringResource(R.string.send_sms_button),
                    style =
                        MaterialTheme.typography.titleMedium.copy(
                            fontWeight = FontWeight.SemiBold
                        ),
                )
            }
        }
    }
}

@Composable
private fun OtpEntryCardContent(
    formattedPhone: String,
    otpCode: String,
    resendSecondsLeft: Int,
    isVerifying: Boolean,
    errorMessage: String?,
    onOtpChanged: (String) -> Unit,
    onVerifyClick: () -> Unit,
    onResendClick: () -> Unit,
    onChangePhoneClick: () -> Unit,
) {
    Column(
        modifier = Modifier.fillMaxWidth().padding(20.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.spacedBy(14.dp),
    ) {
        Text(
            text = stringResource(R.string.otp_title),
            style = MaterialTheme.typography.titleLarge,
            color = MaterialTheme.colorScheme.onSurface,
        )

        Text(
            text = stringResource(R.string.otp_subtitle, formattedPhone),
            style = MaterialTheme.typography.bodyMedium,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            textAlign = TextAlign.Center,
        )

        TextButton(
            onClick = onChangePhoneClick,
            enabled = !isVerifying,
            modifier = Modifier.testTag("change_phone_button"),
        ) {
            Icon(
                imageVector = Icons.Rounded.Edit,
                contentDescription = null,
                modifier = Modifier.size(16.dp),
            )
            Spacer(modifier = Modifier.width(6.dp))
            Text(text = stringResource(R.string.change_phone_button))
        }

        // 6-digit OTP box display backed by a single accessible BasicTextField
        BasicTextField(
            value = otpCode,
            onValueChange = { if (!isVerifying) onOtpChanged(it) },
            enabled = !isVerifying,
            singleLine = true,
            cursorBrush = SolidColor(MaterialTheme.colorScheme.primary),
            keyboardOptions =
                KeyboardOptions(
                    keyboardType = KeyboardType.Number,
                    imeAction = ImeAction.Done,
                ),
            keyboardActions =
                KeyboardActions(
                    onDone = {
                        if (otpCode.length == PhoneAuthViewModel.OTP_LENGTH && !isVerifying) {
                            onVerifyClick()
                        }
                    }
                ),
            modifier = Modifier.fillMaxWidth().testTag("otp_code_input"),
            decorationBox = {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp, Alignment.CenterHorizontally),
                ) {
                    repeat(PhoneAuthViewModel.OTP_LENGTH) { index ->
                        val digit = otpCode.getOrNull(index)?.toString().orEmpty()
                        val isFocusedSlot = otpCode.length == index
                        val borderColor =
                            when {
                                isFocusedSlot -> MaterialTheme.colorScheme.primary
                                digit.isNotEmpty() -> MaterialTheme.colorScheme.primary.copy(alpha = 0.6f)
                                else -> MaterialTheme.colorScheme.outlineVariant
                            }
                        Box(
                            modifier =
                                Modifier.weight(1f)
                                    .height(54.dp)
                                    .clip(RoundedCornerShape(14.dp))
                                    .background(MaterialTheme.colorScheme.surfaceContainer)
                                    .border(
                                        width = if (isFocusedSlot) 2.dp else 1.dp,
                                        color = borderColor,
                                        shape = RoundedCornerShape(14.dp),
                                    ),
                            contentAlignment = Alignment.Center,
                        ) {
                            Text(
                                text = digit,
                                style =
                                    MaterialTheme.typography.headlineMedium.copy(
                                        fontFamily = JetBrainsMonoFamily
                                    ),
                                color = MaterialTheme.colorScheme.onSurface,
                            )
                        }
                    }
                }
            },
        )

        if (errorMessage != null) {
            ErrorBanner(message = errorMessage)
        }

        Button(
            onClick = onVerifyClick,
            enabled = otpCode.length == PhoneAuthViewModel.OTP_LENGTH && !isVerifying,
            shape = RoundedCornerShape(18.dp),
            modifier =
                Modifier.fillMaxWidth()
                    .height(56.dp)
                    .testTag("verify_otp_button"),
        ) {
            if (isVerifying) {
                CircularProgressIndicator(
                    modifier = Modifier.size(22.dp),
                    color = MaterialTheme.colorScheme.onPrimary,
                    strokeWidth = 2.5.dp,
                )
                Spacer(modifier = Modifier.width(10.dp))
                Text(
                    text = stringResource(R.string.verifying_otp_label),
                    style = MaterialTheme.typography.labelLarge,
                )
            } else {
                Text(
                    text = stringResource(R.string.verify_otp_button),
                    style =
                        MaterialTheme.typography.titleMedium.copy(
                            fontWeight = FontWeight.SemiBold
                        ),
                )
            }
        }

        if (resendSecondsLeft > 0) {
            Text(
                text = stringResource(R.string.resend_countdown, resendSecondsLeft),
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
        } else {
            TextButton(
                onClick = onResendClick,
                enabled = !isVerifying,
                modifier = Modifier.testTag("resend_sms_button"),
            ) {
                Text(text = stringResource(R.string.resend_code_button))
            }
        }
    }
}

@Composable
private fun ErrorBanner(message: String) {
    Surface(
        color = MaterialTheme.colorScheme.errorContainer,
        shape = RoundedCornerShape(14.dp),
        modifier = Modifier.fillMaxWidth(),
    ) {
        Text(
            text = message,
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onErrorContainer,
            modifier = Modifier.padding(12.dp),
            textAlign = TextAlign.Center,
        )
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun CountryPickerBottomSheet(
    selectedCountry: CountryCode,
    onSelect: (CountryCode) -> Unit,
    onDismiss: () -> Unit,
) {
    val sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true)
    var query by remember { mutableStateOf("") }
    val filteredCountries =
        remember(query) {
            val q = query.trim().lowercase()
            if (q.isEmpty()) {
                CountryDirectory.all
            } else {
                CountryDirectory.all.filter {
                    it.nameUz.lowercase().contains(q) ||
                        it.dialCode.contains(q) ||
                        it.iso.lowercase().contains(q)
                }
            }
        }

    ModalBottomSheet(
        onDismissRequest = onDismiss,
        sheetState = sheetState,
    ) {
        Column(
            modifier = Modifier.fillMaxWidth().padding(horizontal = 20.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp),
        ) {
            Text(
                text = stringResource(R.string.select_country_title),
                style = MaterialTheme.typography.titleLarge,
                color = MaterialTheme.colorScheme.onSurface,
            )

            OutlinedTextField(
                value = query,
                onValueChange = { query = it },
                placeholder = { Text(text = stringResource(R.string.search_country_hint)) },
                leadingIcon = {
                    Icon(
                        imageVector = Icons.Rounded.Search,
                        contentDescription = null,
                    )
                },
                singleLine = true,
                shape = RoundedCornerShape(16.dp),
                modifier = Modifier.fillMaxWidth().testTag("country_search_input"),
            )

            LazyColumn(
                modifier = Modifier.fillMaxWidth().height(360.dp),
                verticalArrangement = Arrangement.spacedBy(6.dp),
            ) {
                items(
                    items = filteredCountries,
                    key = { "${it.iso}_${it.dialCode}" },
                ) { country ->
                    val isSelected =
                        country.iso == selectedCountry.iso &&
                            country.dialCode == selectedCountry.dialCode
                    Surface(
                        color =
                            if (isSelected) MaterialTheme.colorScheme.primaryContainer
                            else MaterialTheme.colorScheme.surfaceContainer,
                        shape = RoundedCornerShape(14.dp),
                        modifier =
                            Modifier.fillMaxWidth()
                                .clip(RoundedCornerShape(14.dp))
                                .clickable { onSelect(country) }
                                .testTag("country_item_${country.iso}"),
                    ) {
                        Row(
                            modifier = Modifier.padding(horizontal = 14.dp, vertical = 12.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween,
                        ) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                modifier = Modifier.weight(1f),
                            ) {
                                Text(
                                    text = country.flagEmoji,
                                    style = MaterialTheme.typography.titleLarge,
                                )
                                Spacer(modifier = Modifier.width(12.dp))
                                Text(
                                    text = country.nameUz,
                                    style = MaterialTheme.typography.titleMedium,
                                    color = MaterialTheme.colorScheme.onSurface,
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis,
                                )
                            }
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Text(
                                    text = country.dialCode,
                                    style =
                                        MaterialTheme.typography.titleMedium.copy(
                                            fontFamily = JetBrainsMonoFamily
                                        ),
                                    color = MaterialTheme.colorScheme.primary,
                                )
                                if (isSelected) {
                                    Spacer(modifier = Modifier.width(8.dp))
                                    Icon(
                                        imageVector = Icons.Rounded.Check,
                                        contentDescription = null,
                                        tint = MaterialTheme.colorScheme.primary,
                                        modifier = Modifier.size(18.dp),
                                    )
                                }
                            }
                        }
                    }
                }
            }
            Spacer(modifier = Modifier.height(12.dp))
        }
    }
}
