package com.example.ui.auth

import android.app.Activity
import android.util.Log
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.google.firebase.Firebase
import com.google.firebase.FirebaseException
import com.google.firebase.FirebaseNetworkException
import com.google.firebase.FirebaseTooManyRequestsException
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.FirebaseAuthException
import com.google.firebase.auth.FirebaseAuthInvalidCredentialsException
import com.google.firebase.auth.PhoneAuthCredential
import com.google.firebase.auth.PhoneAuthOptions
import com.google.firebase.auth.PhoneAuthProvider
import com.google.firebase.auth.auth
import java.util.concurrent.TimeUnit
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import kotlinx.coroutines.tasks.await

sealed interface PhoneAuthStep {
    data object PhoneEntry : PhoneAuthStep

    data object SendingCode : PhoneAuthStep

    data class OtpEntry(
        val verificationId: String,
        val formattedPhone: String,
        val resendSecondsLeft: Int,
    ) : PhoneAuthStep

    data class VerifyingOtp(
        val verificationId: String,
        val formattedPhone: String,
    ) : PhoneAuthStep
}

data class PhoneAuthUiState(
    val selectedCountry: CountryCode = CountryDirectory.uzbekistan,
    val phoneDigits: String = "",
    val otpCode: String = "",
    val step: PhoneAuthStep = PhoneAuthStep.PhoneEntry,
    val errorMessage: String? = null,
) {
    val fullE164Phone: String
        get() = "${selectedCountry.dialCode}$phoneDigits"

    val isPhoneValid: Boolean
        get() =
            phoneDigits.length in
                selectedCountry.minDigits..selectedCountry.maxDigits
}

class PhoneAuthViewModel(
    private val auth: FirebaseAuth = Firebase.auth,
) : ViewModel() {

    private val _uiState = MutableStateFlow(PhoneAuthUiState())
    val uiState: StateFlow<PhoneAuthUiState> = _uiState.asStateFlow()

    private var resendToken: PhoneAuthProvider.ForceResendingToken? = null
    private var countdownJob: Job? = null

    fun selectCountry(country: CountryCode) {
        _uiState.update { state ->
            state.copy(
                selectedCountry = country,
                phoneDigits = state.phoneDigits.take(country.maxDigits),
                errorMessage = null,
            )
        }
    }

    fun onPhoneDigitsChanged(rawInput: String) {
        val currentCountry = _uiState.value.selectedCountry
        val dialDigits = currentCountry.dialCode.removePrefix("+")
        var cleaned = rawInput.filter { it.isDigit() }
        if (rawInput.trimStart().startsWith("+") && cleaned.startsWith(dialDigits)) {
            cleaned = cleaned.removePrefix(dialDigits)
        }
        cleaned = cleaned.take(currentCountry.maxDigits)
        _uiState.update { it.copy(phoneDigits = cleaned, errorMessage = null) }
    }

    fun onOtpChanged(rawOtp: String) {
        val cleaned = rawOtp.filter { it.isDigit() }.take(OTP_LENGTH)
        _uiState.update { it.copy(otpCode = cleaned, errorMessage = null) }
        if (cleaned.length == OTP_LENGTH) {
            verifyOtpCode()
        }
    }

    fun sendVerificationCode(activity: Activity, isResend: Boolean = false) {
        val currentState = _uiState.value
        if (!currentState.isPhoneValid) {
            _uiState.update {
                it.copy(
                    errorMessage =
                        "Telefon raqami ${currentState.selectedCountry.minDigits}–${currentState.selectedCountry.maxDigits} ta raqamdan iborat bo‘lishi kerak."
                )
            }
            return
        }

        val targetPhone = currentState.fullE164Phone
        val previousVerificationId =
            (currentState.step as? PhoneAuthStep.OtpEntry)?.verificationId

        if (!isResend) {
            _uiState.update { it.copy(step = PhoneAuthStep.SendingCode, errorMessage = null) }
        } else {
            _uiState.update { it.copy(errorMessage = null) }
        }

        val callbacks =
            object : PhoneAuthProvider.OnVerificationStateChangedCallbacks() {
                override fun onVerificationCompleted(credential: PhoneAuthCredential) {
                    signInWithPhoneCredential(credential)
                }

                override fun onVerificationFailed(e: FirebaseException) {
                    Log.e(TAG, "Phone verification failed", e)
                    val friendlyError = mapPhoneAuthError(e)
                    _uiState.update { state ->
                        val fallbackStep =
                            if (isResend && previousVerificationId != null) {
                                PhoneAuthStep.OtpEntry(
                                    verificationId = previousVerificationId,
                                    formattedPhone = targetPhone,
                                    resendSecondsLeft = 0,
                                )
                            } else {
                                PhoneAuthStep.PhoneEntry
                            }
                        state.copy(step = fallbackStep, errorMessage = friendlyError)
                    }
                }

                override fun onCodeSent(
                    verificationId: String,
                    token: PhoneAuthProvider.ForceResendingToken,
                ) {
                    resendToken = token
                    _uiState.update {
                        it.copy(
                            otpCode = "",
                            step =
                                PhoneAuthStep.OtpEntry(
                                    verificationId = verificationId,
                                    formattedPhone = targetPhone,
                                    resendSecondsLeft = RESEND_TIMEOUT_SECONDS,
                                ),
                            errorMessage = null,
                        )
                    }
                    startResendCountdown()
                }
            }

        auth.setLanguageCode("uz")
        val optionsBuilder =
            PhoneAuthOptions.newBuilder(auth)
                .setPhoneNumber(targetPhone)
                .setTimeout(RESEND_TIMEOUT_SECONDS.toLong(), TimeUnit.SECONDS)
                .setActivity(activity)
                .setCallbacks(callbacks)

        if (isResend && resendToken != null) {
            optionsBuilder.setForceResendingToken(resendToken!!)
        }

        try {
            PhoneAuthProvider.verifyPhoneNumber(optionsBuilder.build())
        } catch (e: Exception) {
            Log.e(TAG, "verifyPhoneNumber threw exception", e)
            _uiState.update {
                it.copy(
                    step = PhoneAuthStep.PhoneEntry,
                    errorMessage = mapPhoneAuthError(e),
                )
            }
        }
    }

    fun verifyOtpCode() {
        val state = _uiState.value
        val otpStep = state.step as? PhoneAuthStep.OtpEntry ?: return
        val code = state.otpCode.trim()
        if (code.length != OTP_LENGTH) {
            _uiState.update {
                it.copy(errorMessage = "6 xonali SMS tasdiqlash kodini to‘liq kiriting.")
            }
            return
        }

        _uiState.update {
            it.copy(
                step =
                    PhoneAuthStep.VerifyingOtp(
                        verificationId = otpStep.verificationId,
                        formattedPhone = otpStep.formattedPhone,
                    ),
                errorMessage = null,
            )
        }

        val credential = PhoneAuthProvider.getCredential(otpStep.verificationId, code)
        signInWithPhoneCredential(credential, otpStep.verificationId, otpStep.formattedPhone)
    }

    private fun signInWithPhoneCredential(
        credential: PhoneAuthCredential,
        fallbackVerificationId: String? = null,
        fallbackPhone: String? = null,
    ) {
        viewModelScope.launch {
            try {
                auth.signInWithCredential(credential).await()
                countdownJob?.cancel()
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                Log.e(TAG, "signInWithCredential failed", e)
                val friendlyError = mapPhoneAuthError(e)
                _uiState.update { state ->
                    val nextStep =
                        if (fallbackVerificationId != null && fallbackPhone != null) {
                            PhoneAuthStep.OtpEntry(
                                verificationId = fallbackVerificationId,
                                formattedPhone = fallbackPhone,
                                resendSecondsLeft = 0,
                            )
                        } else {
                            PhoneAuthStep.PhoneEntry
                        }
                    state.copy(step = nextStep, errorMessage = friendlyError)
                }
            }
        }
    }

    fun changePhoneNumber() {
        countdownJob?.cancel()
        resendToken = null
        _uiState.update {
            it.copy(
                otpCode = "",
                step = PhoneAuthStep.PhoneEntry,
                errorMessage = null,
            )
        }
    }

    private fun startResendCountdown() {
        countdownJob?.cancel()
        countdownJob =
            viewModelScope.launch {
                for (sec in (RESEND_TIMEOUT_SECONDS - 1) downTo 0) {
                    delay(1000L)
                    _uiState.update { state ->
                        val currentOtp = state.step as? PhoneAuthStep.OtpEntry
                        if (currentOtp != null) {
                            state.copy(step = currentOtp.copy(resendSecondsLeft = sec))
                        } else {
                            state
                        }
                    }
                }
            }
    }

    private fun mapPhoneAuthError(error: Exception): String {
        val code = (error as? FirebaseAuthException)?.errorCode.orEmpty()
        val msg = error.localizedMessage.orEmpty()
        return when {
            code == "ERROR_OPERATION_NOT_ALLOWED" ||
                msg.contains("operation is not allowed", ignoreCase = true) ->
                "Firebase Console’da Phone Authentication yoqilmagan. Authentication → Sign-in method bo‘limidan Phone xizmatini yoqing."
            error is FirebaseAuthInvalidCredentialsException ||
                code == "ERROR_INVALID_VERIFICATION_CODE" ||
                code == "ERROR_INVALID_PHONE_NUMBER" ->
                "Telefon raqami yoki 6 xonali tasdiqlash kodi noto‘g‘ri."
            code == "ERROR_SESSION_EXPIRED" ->
                "Tasdiqlash kodi muddati tugadi. «Kodni qayta yuborish» tugmasini bosing."
            error is FirebaseTooManyRequestsException || code == "ERROR_TOO_MANY_REQUESTS" ->
                "Juda ko‘p urinish bajarildi. Biroz kutib qaytadan urinib ko‘ring."
            error is FirebaseNetworkException ->
                "Internet aloqasi mavjud emas. Tarmoqni tekshirib qayta urining."
            code == "ERROR_MISSING_CLIENT_IDENTIFIER" ||
                msg.contains("Play Integrity", ignoreCase = true) ||
                msg.contains("reCAPTCHA", ignoreCase = true) ->
                "Qurilma xavfsizlik tekshiruvidan o‘ta olmadi. Internet va Google Play xizmatlarini tekshiring."
            else ->
                msg.ifBlank { "Tasdiqlashda xatolik yuz berdi. Qaytadan urinib ko‘ring." }
        }
    }

    override fun onCleared() {
        super.onCleared()
        countdownJob?.cancel()
    }

    companion object {
        private const val TAG = "PhoneAuthVM"
        const val OTP_LENGTH = 6
        const val RESEND_TIMEOUT_SECONDS = 60
    }
}
