package com.example.ui.viewmodel

import android.util.Log
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.model.ChatRoom
import com.example.data.model.UserProfile
import com.example.data.repository.ChatRepository
import com.google.firebase.firestore.FirebaseFirestoreException
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

sealed interface UiState<out T> {
    data object Loading : UiState<Nothing>

    data class Success<T>(val data: T) : UiState<T>

    data class Error(val message: String) : UiState<Nothing>
}

sealed interface ConnectUiState {
    data object Idle : ConnectUiState

    data object Connecting : ConnectUiState

    data class Error(val message: String) : ConnectUiState
}

class ChatsViewModel(
    private val repository: ChatRepository,
    private val currentUserId: String,
    initialDisplayName: String?,
) : ViewModel() {

    val userProfile: StateFlow<UiState<UserProfile?>> =
        repository
            .observeUserProfile(currentUserId)
            .map<UserProfile?, UiState<UserProfile?>> { UiState.Success(it) }
            .catch { error ->
                val firestoreError =
                    generateSequence(error) { it.cause }
                        .filterIsInstance<FirebaseFirestoreException>()
                        .firstOrNull()
                if (firestoreError == null && error is CancellationException) throw error
                val rootError = firestoreError ?: error
                Log.w(TAG, "Profilni kuzatishda xatolik", rootError)
                emit(UiState.Error(rootError.message ?: "Profil yuklanmadi"))
            }
            .stateIn(
                scope = viewModelScope,
                started = SharingStarted.WhileSubscribed(STOP_TIMEOUT_MILLIS),
                initialValue = UiState.Loading,
            )

    val chats: StateFlow<UiState<List<ChatRoom>>> =
        repository
            .observeChats(currentUserId)
            .map<List<ChatRoom>, UiState<List<ChatRoom>>> { UiState.Success(it) }
            .catch { error ->
                val firestoreError =
                    generateSequence(error) { it.cause }
                        .filterIsInstance<FirebaseFirestoreException>()
                        .firstOrNull()
                if (firestoreError == null && error is CancellationException) throw error
                val rootError = firestoreError ?: error
                Log.w(TAG, "Suhbatlarni kuzatishda xatolik", rootError)
                emit(UiState.Error(rootError.message ?: "Suhbatlar yuklanmadi"))
            }
            .stateIn(
                scope = viewModelScope,
                started = SharingStarted.WhileSubscribed(STOP_TIMEOUT_MILLIS),
                initialValue = UiState.Loading,
            )

    private val _connectState = MutableStateFlow<ConnectUiState>(ConnectUiState.Idle)
    val connectState: StateFlow<ConnectUiState> = _connectState.asStateFlow()

    private val _profileError = MutableStateFlow<String?>(null)
    val profileError: StateFlow<String?> = _profileError.asStateFlow()

    init {
        viewModelScope.launch {
            try {
                repository.ensureUserProfile(initialDisplayName)
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                Log.e(TAG, "Profil yaratishda xatolik", e)
                _profileError.value = "Profil yaratilmadi. Internetni tekshirib qayta urining."
            }
        }
    }

    fun connectByCode(rawCode: String, onChatReady: (String) -> Unit) {
        if (_connectState.value is ConnectUiState.Connecting) return
        viewModelScope.launch {
            _connectState.value = ConnectUiState.Connecting
            val result = repository.connectByLinkCode(rawCode)
            result
                .onSuccess { chatId ->
                    _connectState.value = ConnectUiState.Idle
                    onChatReady(chatId)
                }
                .onFailure { error ->
                    _connectState.value =
                        ConnectUiState.Error(
                            error.message ?: "Bog‘lanib bo‘lmadi. Qaytadan urinib ko‘ring."
                        )
                }
        }
    }

    fun clearConnectError() {
        if (_connectState.value is ConnectUiState.Error) {
            _connectState.value = ConnectUiState.Idle
        }
    }

    fun updateDisplayName(newName: String, linkCode: String) {
        viewModelScope.launch {
            try {
                repository.updateDisplayName(newName, linkCode)
                _profileError.value = null
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                Log.e(TAG, "Ismni yangilashda xatolik", e)
                _profileError.value = e.message ?: "Ismni yangilab bo‘lmadi"
            }
        }
    }

    private companion object {
        const val TAG = "ChatsVM"
        const val STOP_TIMEOUT_MILLIS = 5000L
    }
}
