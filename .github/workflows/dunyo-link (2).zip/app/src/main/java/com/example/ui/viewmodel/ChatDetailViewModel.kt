package com.example.ui.viewmodel

import android.util.Log
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.model.ChatMessage
import com.example.data.model.ChatRoom
import com.example.data.model.UserProfile
import com.example.data.repository.ChatRepository
import com.google.firebase.firestore.FirebaseFirestoreException
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

class ChatDetailViewModel(
    private val repository: ChatRepository,
    private val currentUserId: String,
    private val chatId: String,
    private val fallbackDisplayName: String,
) : ViewModel() {

    val chatRoom: StateFlow<ChatRoom?> =
        repository
            .observeChatRoom(chatId)
            .catch { error ->
                val firestoreError =
                    generateSequence(error) { it.cause }
                        .filterIsInstance<FirebaseFirestoreException>()
                        .firstOrNull()
                if (firestoreError == null && error is CancellationException) throw error
                Log.w(TAG, "Suhbat xonasini kuzatishda xatolik", firestoreError ?: error)
                emit(null)
            }
            .stateIn(
                scope = viewModelScope,
                started = SharingStarted.WhileSubscribed(STOP_TIMEOUT_MILLIS),
                initialValue = null,
            )

    val myProfile: StateFlow<UserProfile?> =
        repository
            .observeUserProfile(currentUserId)
            .catch { error ->
                val firestoreError =
                    generateSequence(error) { it.cause }
                        .filterIsInstance<FirebaseFirestoreException>()
                        .firstOrNull()
                if (firestoreError == null && error is CancellationException) throw error
                emit(null)
            }
            .stateIn(
                scope = viewModelScope,
                started = SharingStarted.WhileSubscribed(STOP_TIMEOUT_MILLIS),
                initialValue = null,
            )

    val messagesState: StateFlow<UiState<List<ChatMessage>>> =
        repository
            .observeMessages(chatId, currentUserId)
            .map<List<ChatMessage>, UiState<List<ChatMessage>>> { UiState.Success(it) }
            .catch { error ->
                val firestoreError =
                    generateSequence(error) { it.cause }
                        .filterIsInstance<FirebaseFirestoreException>()
                        .firstOrNull()
                if (firestoreError == null && error is CancellationException) throw error
                val rootError = firestoreError ?: error
                Log.w(TAG, "Xabarlarni kuzatishda xatolik", rootError)
                emit(UiState.Error(rootError.message ?: "Xabarlarni yuklab bo‘lmadi"))
            }
            .stateIn(
                scope = viewModelScope,
                started = SharingStarted.WhileSubscribed(STOP_TIMEOUT_MILLIS),
                initialValue = UiState.Loading,
            )

    private val _isSending = MutableStateFlow(false)
    val isSending: StateFlow<Boolean> = _isSending.asStateFlow()

    private val _sendError = MutableStateFlow<String?>(null)
    val sendError: StateFlow<String?> = _sendError.asStateFlow()

    fun sendMessage(rawText: String, onSent: () -> Unit) {
        val text = rawText.trim()
        if (text.isEmpty() || _isSending.value) return
        val room = chatRoom.value ?: return
        val participants = room.participantIds
        if (participants.size != 2) return

        val senderName =
            myProfile.value?.displayName?.takeIf { it.isNotBlank() }
                ?: fallbackDisplayName.ifBlank { "Foydalanuvchi" }

        viewModelScope.launch {
            _isSending.value = true
            _sendError.value = null
            val result =
                repository.sendMessage(
                    chatId = chatId,
                    participantIds = participants,
                    senderName = senderName,
                    text = text,
                )
            _isSending.value = false
            result
                .onSuccess { onSent() }
                .onFailure { error ->
                    _sendError.value =
                        error.message ?: "Xabar yuborilmadi. Internet aloqasini tekshiring."
                }
        }
    }

    fun dismissSendError() {
        _sendError.value = null
    }

    private companion object {
        const val TAG = "ChatDetailVM"
        const val STOP_TIMEOUT_MILLIS = 5000L
    }
}
