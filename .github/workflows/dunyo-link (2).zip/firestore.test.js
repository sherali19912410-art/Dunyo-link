const {
  initializeTestEnvironment,
  assertFails,
  assertSucceeds,
} = require("@firebase/rules-unit-testing");
const { test, before, after, beforeEach } = require("node:test");
const fs = require("node:fs");

let testEnv;
const PROJECT_ID = process.env.GCP_PROJECT || "demo-no-project";
const ALICE_UID = "alice_123";
const BOB_UID = "bob_456";
const CHARLIE_UID = "charlie_789";
const CHAT_ID = `${ALICE_UID}_${BOB_UID}`;

const [emulatorHost, emulatorPortStr] = (
  process.env.FIRESTORE_EMULATOR_HOST || "127.0.0.1:8085"
).split(":");
const emulatorPort = parseInt(emulatorPortStr, 10);

function pastTimestamp() {
  return new Date(Date.now() - 5000);
}

before(async () => {
  const rules = fs.readFileSync("./firestore.rules", "utf8");
  testEnv = await initializeTestEnvironment({
    projectId: PROJECT_ID,
    firestore: {
      rules,
      host: emulatorHost,
      port: emulatorPort,
    },
  });
});

after(async () => {
  if (testEnv) {
    await testEnv.cleanup();
  }
});

beforeEach(async () => {
  if (testEnv) {
    await testEnv.clearFirestore();
  }
});

// --- /users/{userId} TESTS ---

test("Unauthenticated user: cannot read or write users", async () => {
  const unauthDb = testEnv.unauthenticatedContext().firestore();
  await assertFails(unauthDb.collection("users").doc(ALICE_UID).get());
  await assertFails(unauthDb.collection("users").get());
});

test("User profile: owner can create and read own profile, cannot read others", async () => {
  const aliceDb = testEnv.authenticatedContext(ALICE_UID).firestore();
  const bobDb = testEnv.authenticatedContext(BOB_UID).firestore();
  const ts = pastTimestamp();

  await assertSucceeds(
    aliceDb.collection("users").doc(ALICE_UID).set({
      userId: ALICE_UID,
      displayName: "Ali",
      linkCode: "DL1001",
      avatarColorIndex: 2,
      createdAt: ts,
      updatedAt: ts,
    })
  );

  await assertSucceeds(aliceDb.collection("users").doc(ALICE_UID).get());
  await assertFails(bobDb.collection("users").doc(ALICE_UID).get());
  await assertFails(bobDb.collection("users").get());
});

test("User profile: rejects shadow ghost fields and linkCode mutation", async () => {
  const aliceDb = testEnv.authenticatedContext(ALICE_UID).firestore();
  const ts = pastTimestamp();

  await assertFails(
    aliceDb.collection("users").doc(ALICE_UID).set({
      userId: ALICE_UID,
      displayName: "Ali",
      linkCode: "DL1001",
      avatarColorIndex: 2,
      isAdmin: true,
      createdAt: ts,
      updatedAt: ts,
    })
  );

  await assertSucceeds(
    aliceDb.collection("users").doc(ALICE_UID).set({
      userId: ALICE_UID,
      displayName: "Ali",
      linkCode: "DL1001",
      avatarColorIndex: 2,
      createdAt: ts,
      updatedAt: ts,
    })
  );

  await assertFails(
    aliceDb.collection("users").doc(ALICE_UID).update({
      linkCode: "HACK99",
      updatedAt: pastTimestamp(),
    })
  );
});

// --- /link_codes/{code} TESTS ---

test("Link codes: owner can create, any signed-in user can get by exact code, list is blocked", async () => {
  const aliceDb = testEnv.authenticatedContext(ALICE_UID).firestore();
  const bobDb = testEnv.authenticatedContext(BOB_UID).firestore();
  const unauthDb = testEnv.unauthenticatedContext().firestore();
  const ts = pastTimestamp();

  await assertSucceeds(
    aliceDb.collection("link_codes").doc("A1B2C3").set({
      code: "A1B2C3",
      uid: ALICE_UID,
      displayName: "Ali",
      avatarColorIndex: 1,
      createdAt: ts,
      updatedAt: ts,
    })
  );

  // Bob can look up exact code
  await assertSucceeds(bobDb.collection("link_codes").doc("A1B2C3").get());
  // Nobody can list/scrape all codes
  await assertFails(bobDb.collection("link_codes").get());
  // Unauthenticated cannot get
  await assertFails(unauthDb.collection("link_codes").doc("A1B2C3").get());
  // Bob cannot overwrite Alice's link code
  await assertFails(
    bobDb.collection("link_codes").doc("A1B2C3").update({
      displayName: "Spoof",
      updatedAt: pastTimestamp(),
    })
  );
});

// --- /chats/{chatId} AND /chats/{chatId}/messages TESTS ---

test("Chats & Messages: participants can create chat, send messages, list own chats & messages", async () => {
  const aliceDb = testEnv.authenticatedContext(ALICE_UID).firestore();
  const bobDb = testEnv.authenticatedContext(BOB_UID).firestore();
  const charlieDb = testEnv.authenticatedContext(CHARLIE_UID).firestore();
  const ts = pastTimestamp();

  // Check get on non-existent chatId before creation
  await assertSucceeds(aliceDb.collection("chats").doc(CHAT_ID).get());

  await assertSucceeds(
    aliceDb.collection("chats").doc(CHAT_ID).set({
      participantIds: [ALICE_UID, BOB_UID],
      participantOneId: ALICE_UID,
      participantOneName: "Ali",
      participantTwoId: BOB_UID,
      participantTwoName: "Bobur",
      lastMessageText: "",
      lastMessageSenderId: "",
      lastMessageAt: ts,
      createdAt: ts,
      updatedAt: ts,
    })
  );

  // Client-aligned queries succeed for participants
  await assertSucceeds(
    aliceDb.collection("chats").where("participantIds", "array-contains", ALICE_UID).get()
  );
  await assertSucceeds(
    bobDb.collection("chats").where("participantIds", "array-contains", BOB_UID).get()
  );

  // Unfiltered chats query fails (rules are not filters)
  await assertFails(aliceDb.collection("chats").get());
  // Charlie cannot read or query Alice-Bob chat
  await assertFails(charlieDb.collection("chats").doc(CHAT_ID).get());

  // Alice sends a message
  await assertSucceeds(
    aliceDb.collection("chats").doc(CHAT_ID).collection("messages").doc("msg_1").set({
      senderId: ALICE_UID,
      senderName: "Ali",
      text: "Salom Bobur!",
      participantIds: [ALICE_UID, BOB_UID],
      createdAt: pastTimestamp(),
    })
  );

  // Update chat last message
  await assertSucceeds(
    aliceDb.collection("chats").doc(CHAT_ID).update({
      lastMessageText: "Salom Bobur!",
      lastMessageSenderId: ALICE_UID,
      lastMessageAt: pastTimestamp(),
      updatedAt: pastTimestamp(),
    })
  );

  // Bob reads messages using aligned query
  await assertSucceeds(
    bobDb
      .collection("chats")
      .doc(CHAT_ID)
      .collection("messages")
      .where("participantIds", "array-contains", BOB_UID)
      .get()
  );

  // Charlie cannot create or read messages in Alice-Bob chat
  await assertFails(
    charlieDb.collection("chats").doc(CHAT_ID).collection("messages").doc("msg_2").set({
      senderId: CHARLIE_UID,
      senderName: "Charli",
      text: "Intrusion!",
      participantIds: [ALICE_UID, BOB_UID],
      createdAt: pastTimestamp(),
    })
  );
  await assertFails(
    charlieDb
      .collection("chats")
      .doc(CHAT_ID)
      .collection("messages")
      .get()
  );
  await assertFails(
    charlieDb
      .collection("chats")
      .doc(CHAT_ID)
      .collection("messages")
      .doc("msg_1")
      .get()
  );
  const charlieSnap = await assertSucceeds(
    charlieDb
      .collection("chats")
      .doc(CHAT_ID)
      .collection("messages")
      .where("participantIds", "array-contains", CHARLIE_UID)
      .get()
  );
  if (!charlieSnap.empty) {
    throw new Error("Expected Charlie query to return 0 messages");
  }
});

test("Messages: prevents senderId spoofing, chatId mismatch, and message tampering", async () => {
  const aliceDb = testEnv.authenticatedContext(ALICE_UID).firestore();
  const bobDb = testEnv.authenticatedContext(BOB_UID).firestore();
  const ts = pastTimestamp();

  await assertSucceeds(
    aliceDb.collection("chats").doc(CHAT_ID).set({
      participantIds: [ALICE_UID, BOB_UID],
      participantOneId: ALICE_UID,
      participantOneName: "Ali",
      participantTwoId: BOB_UID,
      participantTwoName: "Bobur",
      lastMessageText: "",
      lastMessageSenderId: "",
      lastMessageAt: ts,
      createdAt: ts,
      updatedAt: ts,
    })
  );

  // Sender spoofing rejected
  await assertFails(
    aliceDb.collection("chats").doc(CHAT_ID).collection("messages").doc("msg_spoof").set({
      senderId: BOB_UID,
      senderName: "Bobur",
      text: "Spoofed!",
      participantIds: [ALICE_UID, BOB_UID],
      createdAt: pastTimestamp(),
    })
  );

  // Empty text rejected
  await assertFails(
    aliceDb.collection("chats").doc(CHAT_ID).collection("messages").doc("msg_empty").set({
      senderId: ALICE_UID,
      senderName: "Ali",
      text: "",
      participantIds: [ALICE_UID, BOB_UID],
      createdAt: pastTimestamp(),
    })
  );

  // Create valid message then try to update/delete
  await assertSucceeds(
    aliceDb.collection("chats").doc(CHAT_ID).collection("messages").doc("msg_ok").set({
      senderId: ALICE_UID,
      senderName: "Ali",
      text: "Assalomu alaykum",
      participantIds: [ALICE_UID, BOB_UID],
      createdAt: pastTimestamp(),
    })
  );

  await assertFails(
    aliceDb.collection("chats").doc(CHAT_ID).collection("messages").doc("msg_ok").update({
      text: "Edited",
    })
  );
  await assertFails(
    bobDb.collection("chats").doc(CHAT_ID).collection("messages").doc("msg_ok").delete()
  );
});
